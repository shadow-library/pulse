var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthGuard_1;
import { AppError, Logger, throwError } from '@shadow-library/common';
import { ContextService, Middleware } from '@shadow-library/fastify';
/**
 * Importing user defined packages
 */
import { NAMESPACE } from '../constants.js';
import { AuthErrorCode } from '../errors.js';
import { AuthClient } from '../lib/auth-client.js';
import { AppSessionService } from './app-session.service.js';
import { AUTH_ROUTE_METADATA } from './constants.js';
import { AUTH_PRINCIPAL } from './context.js';
import { parseCookies } from './cookie.js';
import { AuthGuardErrorCode } from './errors.js';
/**
 * Declaring the constants
 *
 * The guard only attaches to routes that carry auth metadata, so unguarded routes pay no cost. A
 * caller may present either an `Authorization: Bearer` token or the application's session cookie, and
 * both land in the same principal — a route handler never learns which was used. Every failure is
 * mapped to the same generic 401/403 pair; the response never explains which check failed, only the
 * audit-friendly error code differs. The single exception is `IAM_003`, because "step up" is
 * instruction rather than information. M2M callers stay deny-by-default: a service token passes only
 * when an admin-configured service-access rule covers this route for that caller.
 */
/** 302 keeps the browser's method on a redirect the user follows interactively */
const FOUND = 302;
/** Only a top-level navigation gets bounced; anything else is answered with a status a client can act on */
const isNavigation = (request, method) => {
    const accept = request.headers.accept;
    return method.toUpperCase() === 'GET' && typeof accept === 'string' && accept.includes('text/html');
};
let AuthGuard = AuthGuard_1 = class AuthGuard {
    client;
    context;
    sessions;
    logger = Logger.getLogger(NAMESPACE, AuthGuard_1.name);
    constructor(client, context, sessions) {
        this.client = client;
        this.context = context;
        this.sessions = sessions;
    }
    /** The router caches generated handlers by metadata alone; namespacing avoids colliding with other generating middlewares on the same route */
    cacheKey(metadata) {
        return `shadow-auth:${String(metadata.method)}:${String(metadata.path)}`;
    }
    generate(metadata) {
        const auth = metadata[AUTH_ROUTE_METADATA];
        if (!auth?.authenticated)
            return undefined;
        const method = String(metadata.method ?? '*');
        const path = String(metadata.path ?? '/');
        return async (request, response) => {
            try {
                const principal = await this.authenticate(request, auth);
                this.authorize(principal, auth, method, path);
                if (auth.permission)
                    await this.checkPermission(principal, auth);
                this.context.set(AUTH_PRINCIPAL, principal);
                this.logger.debug('request authenticated', { sub: principal.sub, kind: principal.kind, aal: principal.aal, method, path });
                return undefined;
            }
            catch (error) {
                return this.recover(error, request, response, method);
            }
        };
    }
    async authenticate(request, auth) {
        const header = request.headers.authorization;
        const token = typeof header === 'string' && header.startsWith('Bearer ') ? header.slice(7) : undefined;
        if (token)
            return this.client.verify(token).catch((error) => throwError(this.unauthenticated(error)));
        const sessions = this.sessions;
        const handle = sessions && sessions.readHandle(parseCookies(request.headers.cookie));
        if (!sessions || !handle)
            throw AuthGuardErrorCode.IAM_001.create();
        /** A cookie caller has no token yet: the SDK mints one for this app's own audience and verifies it offline, exactly as it would a presented bearer */
        return sessions.resolvePrincipal(handle, { elevated: auth.elevated });
    }
    authorize(principal, auth, method, path) {
        if (principal.kind === 'service' && (!principal.clientId || !this.client.isServiceCallerAllowed(principal.clientId, method, path))) {
            throw this.denied('service caller not allowed for this route', { clientId: principal.clientId, method, path });
        }
        if (auth.scopes?.some(scope => !principal.scopes.includes(scope)))
            throw this.denied('token lacks a required scope', { sub: principal.sub, requiredScopes: auth.scopes });
        if (auth.elevated && principal.aal !== 'AAL2')
            throw AuthErrorCode.ELEVATION_REQUIRED.create({ reason: 'the presented credential is not elevated' });
    }
    async checkPermission(principal, auth) {
        const permission = auth.permission;
        const options = { failOpen: auth.failOpen, highRisk: auth.highRisk };
        const permitted = principal.org ? await this.client.check({ action: permission, organisationId: principal.org, principal }, options) : (auth.failOpen ?? false);
        if (!permitted)
            throw this.denied('permission denied', { sub: principal.sub, permission });
    }
    /**
     * Turns the two recoverable failures into the move that actually resolves them. A browser gets
     * bounced — to login when its session died, to step-up when the route needs `AAL2` — while every
     * other caller gets a status it can branch on. Nothing here ever falls through as anonymous.
     */
    async recover(error, request, response, method) {
        const sessions = this.sessions;
        const returnTo = request.url ?? '/';
        if (AppError.is(error, AuthErrorCode.SESSION_INVALID)) {
            this.logger.warn('app session rejected; clearing the cookie and restarting the login', { method });
            if (!sessions)
                throw AuthGuardErrorCode.IAM_001.create();
            for (const cookie of sessions.clearedCookies())
                response?.header('set-cookie', cookie);
            if (!response || !isNavigation(request, method))
                throw AuthGuardErrorCode.IAM_001.create();
            return this.bounce(response, sessions.loginUrl(returnTo));
        }
        /** A mismatch lands here too: the step-up route is where the prompt is restarted with this app's intent */
        if (AppError.is(error, AuthErrorCode.ELEVATION_REQUIRED) || AppError.is(error, AuthErrorCode.ELEVATION_INTENT_MISMATCH)) {
            this.logger.warn('route requires elevation and the principal is not elevated', { method });
            if (!sessions || !response || !isNavigation(request, method))
                throw AuthGuardErrorCode.IAM_003.create();
            return this.bounce(response, sessions.stepUpUrl(returnTo));
        }
        /**
         * Everything else collapses back to the generic pair. The cookie path can fail with the SDK's own
         * codes — a broken scope grant, an unreachable identity — and none of that is the browser's
         * business; leaking it would tell an unauthenticated caller how this service is configured.
         */
        if (AppError.is(error, AuthGuardErrorCode))
            throw error;
        throw this.unauthenticated(error instanceof Error ? error : new Error(String(error)));
    }
    /**
     * Fastify skips the route handler only once the reply has finished writing, and a hook that merely
     * *returns* the reply does not reliably get there first — the handler then runs unauthenticated and
     * the error handler tries to write a response that has already gone out. Awaiting the redirect is
     * what makes the bounce terminal.
     */
    async bounce(response, url) {
        await response.redirect(url, FOUND);
        return response;
    }
    /** Warn-level trail for rejected credentials; the response stays a generic 401 */
    unauthenticated(error) {
        this.logger.warn('bearer token rejected', { reason: error.message });
        return AuthGuardErrorCode.IAM_001.create();
    }
    /** Warn-level trail for denied requests; the response stays a generic 403 */
    denied(message, metadata) {
        this.logger.warn(message, metadata);
        return AuthGuardErrorCode.IAM_002.create();
    }
};
AuthGuard = AuthGuard_1 = __decorate([
    Middleware({ type: 'preHandler', weight: 100 }),
    __metadata("design:paramtypes", [AuthClient,
        ContextService,
        AppSessionService])
], AuthGuard);
export { AuthGuard };
