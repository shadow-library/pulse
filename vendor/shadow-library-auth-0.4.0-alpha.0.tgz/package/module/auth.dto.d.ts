/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
/**
 * Declaring the constants
 *
 * The query and body shapes keep their wire names: `return_to`, `logout_token` and the OAuth error
 * parameters are spelled by their specifications, and renaming them here would only hide which
 * parameter a failure is actually about. Every query schema stays open to additional properties so a
 * future identity release can add one without this SDK rejecting the callback.
 */
export declare class AuthLoginQuery {
    /** Where to land once the login completes; validated against the redirect allow-list, never trusted */
    return_to?: string;
}
export declare class AuthCallbackQuery {
    code?: string;
    state?: string;
    /** Present instead of `code` when the user declined or identity refused the request */
    error?: string;
    error_description?: string;
}
export declare class AuthStepUpQuery {
    return_to?: string;
    /** Set on the way back from identity, so a step-up that still cannot be claimed fails instead of looping */
    claimed?: string;
    /** Set after a prompt was restarted for an intent mismatch, so a second mismatch fails instead of looping */
    retried?: string;
}
export declare class BackchannelLogoutBody {
    logout_token: string;
}
export declare class AuthSessionResponse {
    sub: string;
    scopes: string[];
    org?: string;
    /** `AAL2` only while a step-up grant for this application's audience is live */
    aal?: string;
    clientId?: string;
}
export declare class AuthLogoutResponse {
    success: boolean;
    /** Set when identity's RP-initiated logout should be visited next */
    redirectTo?: string;
}
export declare class BackchannelLogoutResponse {
    success: boolean;
}
