/**
 * Importing npm packages
 */
/**
 * Defining types
 */
export type SameSitePolicy = 'Lax' | 'Strict' | 'None';
export interface CookieAttributes {
    path: string;
    httpOnly: boolean;
    secure: boolean;
    sameSite: SameSitePolicy;
    /** Lifetime in seconds; omitted, the cookie is a session cookie */
    maxAge?: number;
    domain?: string;
}
export declare function assertValidCookieName(name: string, attributes: CookieAttributes): void;
/**
 * A request's cookies are attacker-influenced input: any page on a sibling subdomain can plant a
 * malformed one. Nothing in here may throw, or a single junk cookie would wedge every request from
 * that browser into a 500 with no way for the user to recover.
 */
export declare function parseCookies(header: string | string[] | undefined): Record<string, string>;
export declare function serializeCookie(name: string, value: string, attributes: CookieAttributes): string;
/** An immediate expiry carrying the same attributes, which is what makes a browser actually drop it */
export declare function expireCookie(name: string, attributes: CookieAttributes): string;
