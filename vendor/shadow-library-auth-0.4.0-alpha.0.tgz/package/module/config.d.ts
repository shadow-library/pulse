import { type AuthClientConfig } from '../interfaces.js';
import { type CookieAttributes, type SameSitePolicy } from './cookie.js';
/**
 * Defining types
 */
declare module '@shadow-library/common' {
    interface ConfigRecords {
        /** Auth SDK configs (consumed by `AuthModule.forRoot` / `RelyingPartyModule.forRoot`) */
        'auth.issuer': string;
        'auth.app-id': string;
        'auth.client.id': string;
        'auth.client.secret': string;
        'auth.client.assertion-path': string;
        'auth.timeout': number;
        'auth.app.refresh-seconds': number;
        'auth.service-access.refresh-seconds': number;
        'auth.strict-scopes': boolean;
        /** First-party browser flow configs (consumed by `AuthModule.forRoot`) */
        'auth.browser-login': boolean;
        'auth.session.cookie-name': string;
        'auth.session.cookie-secure': boolean;
        'auth.session.cookie-same-site': SameSitePolicy;
        'auth.session.cookie-domain': string;
        'auth.post-login-redirect': string;
        'auth.post-logout-redirect': string;
        'auth.allowed-redirects': string[];
    }
}
/** The browser-facing surface `AuthModule.forRoot()` registers; every path is overridable and any route may be turned off */
export interface AuthRoutePaths {
    basePath: string;
    login: string | false;
    callback: string | false;
    logout: string | false;
    backchannelLogout: string | false;
    session: string | false;
    stepUp: string | false;
}
export interface BrowserAuthOptions {
    /**
     * Defaults to on whenever a credential is configured, because identity already knows this
     * application's redirect URIs and granted scopes — there is nothing left for a deploy to supply.
     * An API-only service turns it off here or with `AUTH_BROWSER_LOGIN=false`.
     */
    enabled?: boolean;
    /**
     * Overrides the redirect URI identity has registered for this application. Only for a deployment
     * behind a proxy that rewrites the callback path; normally the registration is the truth.
     */
    redirectUri?: string;
    /** Overrides the scopes an admin granted this application; narrows, it cannot grant */
    scopes?: string[];
    /** Overrides discovery's `step_up_endpoint`; the endpoint is derived, not configured */
    stepUpUrl?: string;
    postLoginRedirect?: string;
    /** Where identity sends the browser after an RP-initiated logout; omitted, logout ends here */
    postLogoutRedirect?: string;
    /** Absolute origins (optionally with a path prefix) a `return_to` may point at; same-origin paths are always allowed */
    allowedRedirects?: string[];
    cookieName?: string;
    cookieSameSite?: SameSitePolicy;
    cookieDomain?: string;
    /**
     * The escape hatch for plain-HTTP development only. Turning it off drops the `Secure` attribute and
     * therefore the `__Host-` prefix with it, which is why it warns loudly and must never reach production.
     */
    cookieSecure?: boolean;
    /** Checks the granted scopes against the issuer's published `scopes_supported` at startup; on by default */
    validateScopes?: boolean;
}
/** Everything is optional: whatever is not passed in code is resolved from the environment */
export interface AuthModuleOptions extends Partial<AuthClientConfig> {
    browser?: BrowserAuthOptions;
    routes?: Partial<AuthRoutePaths>;
}
/**
 * The locally-decided half of the browser configuration. Audience, redirect URI, granted scopes and
 * the step-up endpoint are deliberately absent: they come from identity at runtime (D-21), so they
 * cannot be settled here at `forRoot()` time. Only the overrides for them live here.
 */
export interface ResolvedBrowserAuthConfig {
    enabled: boolean;
    routes: AuthRoutePaths;
    redirectUri?: string;
    scopes?: string[];
    stepUpUrl?: string;
    postLoginRedirect: string;
    postLogoutRedirect?: string;
    allowedRedirects: string[];
    validateScopes: boolean;
    cookieName: string;
    cookie: CookieAttributes;
    stateCookieName: string;
    stateCookie: CookieAttributes;
}
/** Fills any option not supplied in code from the corresponding `AUTH_*` environment config */
export declare function resolveAuthClientConfig(options?: AuthModuleOptions): AuthClientConfig;
export declare function resolveAuthRoutes(overrides?: Partial<AuthRoutePaths>): AuthRoutePaths;
/**
 * Resolves the browser-facing half. It stays off without client credentials, because minting on a
 * browser's behalf is impossible without the application's own M2M credential — registering the
 * routes anyway would only hand callers a login that cannot complete.
 */
export declare function resolveBrowserAuthConfig(client: AuthClientConfig, routes: AuthRoutePaths, options?: BrowserAuthOptions): ResolvedBrowserAuthConfig;
