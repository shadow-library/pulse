/**
 * Importing npm packages
 */
import { Handler } from '@shadow-library/app';
/**
 * Importing user defined packages
 */
import { AUTH_ROUTE_METADATA } from './constants.js';
/**
 * Declaring the constants
 *
 * There is deliberately no per-route service allowlist decorator: which M2M callers may reach
 * which routes is administered centrally in the identity admin panel and loaded by `AuthModule`
 * at startup, so route code never hard-codes caller identities.
 */
const authRoute = (metadata) => Handler({ [AUTH_ROUTE_METADATA]: metadata });
/** Requires a valid bearer token; the resolved principal is exposed via `context.getAuthPrincipal()` */
export const Authenticated = () => authRoute({ authenticated: true });
/** Requires a valid bearer token carrying every listed scope */
export const RequireScope = (...scopes) => authRoute({ authenticated: true, scopes });
/** Requires a PDP PERMIT for the action, checked in the principal's organisation (implies `@Authenticated`) */
export const RequirePermission = (permission, options = {}) => authRoute({ authenticated: true, permission, ...options });
/**
 * Requires an `AAL2` principal, minted from a step-up grant scoped to this application's audience
 * (D-19). For a browser session the SDK drives the whole cycle — claim, prompt if there is nothing to
 * claim, retry — while a bearer caller is answered with `IAM_003` so it can drive the cycle itself.
 *
 * Elevation is deliberately not contagious: the elevated token is minted for these routes only and
 * never attached to ordinary requests, so a user working across two applications steps up in each.
 */
export const RequireElevation = (...scopes) => authRoute({ authenticated: true, elevated: true, ...(scopes.length > 0 && { scopes }) });
