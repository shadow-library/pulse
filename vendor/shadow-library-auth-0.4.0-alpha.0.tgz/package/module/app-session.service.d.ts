import { AppSessionToken, AuthPrincipal } from '../interfaces.js';
import { AuthClient } from '../lib/auth-client.js';
import { ResolvedBrowserAuthConfig } from './config.js';
/**
 * Defining types
 */
export interface LoginRedirect {
    url: string;
    /** The transient login-state cookie: `__Host-`-prefixed, `HttpOnly`, and cleared on first use */
    cookies: string[];
}
export interface LoginResult {
    cookies: string[];
    returnTo: string;
    userId: string;
}
export interface TokenRequest {
    /** Requires a token minted from a live step-up grant for this app's audience */
    elevated?: boolean;
}
/**
 * The half of the browser configuration identity owns (D-21), resolved per request from the
 * application's registration and refreshed with it — so an admin granting a scope or registering a
 * redirect URI reaches a running service without a redeploy.
 */
export interface BrowserAuthRuntime {
    clientId: string;
    audience: string;
    redirectUri: string;
    scopes: string[];
    stepUpUrl: string;
}
export declare class AppSessionService {
    private readonly client;
    private readonly config;
    private readonly logger;
    private readonly tokens;
    private readonly registry;
    /**
     * Elevation grant windows in epoch milliseconds, keyed by session hash. The D-19 isolation boundary
     * is (app session, audience), but a service only ever mints for its own audience, so the audience is
     * a constant here — carrying it in the key would only invite a stale one into a lookup.
     */
    private readonly grants;
    /** The last runtime derived from a registration, kept so an unchanged registration costs nothing */
    private derived;
    constructor(client: AuthClient, config: ResolvedBrowserAuthConfig);
    /**
     * Resolves the identity-owned half of the configuration and validates what a deploy can still get
     * wrong. Called once at startup so a misregistration surfaces at boot rather than on a user's first
     * login, and cheap afterwards — the registration is cached and refreshed on its own TTL.
     */
    warmUp(): Promise<BrowserAuthRuntime>;
    /** Starts a login: PKCE, `state`, `nonce` and `resource` out; the transient state rides in its own cookie */
    beginLogin(returnTo?: string): Promise<LoginRedirect>;
    /** Completes the callback: validates `state`, redeems the code for a handle, and sets the session cookie */
    completeLogin(query: {
        code?: string;
        state?: string;
    }, cookies: Record<string, string>): Promise<LoginResult>;
    /**
     * Resolves the caller behind a session cookie into the same principal a bearer token would produce:
     * an access token for this app's own audience, minted or served from cache, then verified through
     * the ordinary offline path. Route handlers never learn which credential the caller presented.
     */
    resolvePrincipal(handle: string, request?: TokenRequest): Promise<AuthPrincipal>;
    /** The cached-or-minted access token for this app's audience; elevation is part of the cache key, never a property of the entry */
    getAccessToken(handle: string, request?: TokenRequest): Promise<AppSessionToken>;
    /**
     * Spends the user's step-up into a grant for this app session and this audience only. Elevation
     * never bleeds to another service or up to the parent identity session, which is exactly why a
     * user driving two applications must step up in each — the cost of the isolation, not a defect.
     */
    claimElevation(handle: string): Promise<void>;
    /**
     * Ends this application's session only; the central identity session is deliberately untouched.
     * The handle is marked dead locally whether or not identity confirms it — a revocation that times
     * out must not leave a logged-out handle quietly replayable against this process.
     */
    logout(handle: string | undefined): Promise<string[]>;
    /** Drops every local session of the user identity has signed out, along with their cached tokens */
    handleBackchannelLogout(logoutToken: string): Promise<void>;
    /** Reads the opaque handle out of the request's cookies; absent means "not logged in", never "anonymous but fine" */
    readHandle(cookies: Record<string, string>): string | undefined;
    clearedCookies(): string[];
    /** This service's own login route, carrying where the browser should land once it is back */
    loginUrl(returnTo: string): string;
    /**
     * This service's own step-up route. The guard sends the browser here rather than straight to
     * identity, because the user may already have stepped up elsewhere — in which case claiming the
     * grant is enough and no second prompt is needed.
     */
    stepUpUrl(returnTo: string): string;
    /**
     * Identity's step-up prompt, for when there is no step-up left to claim. It names its beneficiary:
     * without `client_id` and `resource` the resulting window is unattributed, and any application the
     * user happens to be driving could claim it first — the D-19 acquisition race. With them, identity
     * records who the step-up was for and refuses a claim from anybody else.
     */
    identityStepUpUrl(returnTo: string): Promise<string>;
    private localUrl;
    /** Identity's RP-initiated logout, when one is configured; otherwise the browser stays on this app */
    endSessionUrl(): Promise<string | undefined>;
    /**
     * Validates a `return_to` against the allow-list. Same-origin absolute paths are always fine;
     * anything else must be named in configuration. The check runs on a slash-normalised copy because
     * a browser folds backslashes into slashes for http(s): `//evil.test` and `/\evil.test` both read
     * as a path to a careless comparison and as an origin to the thing that actually follows them.
     */
    resolveReturnTo(candidate: string | undefined): string;
    private assertAllowedRedirect;
    /**
     * An allow-list entry matches on exact origin, and on path prefix when it names one. Both sides
     * must be http(s): every other scheme reports its origin as the string `"null"`, which would make
     * one custom-scheme entry match every custom-scheme target.
     */
    private covers;
    private mint;
    /**
     * Merges what identity says about this application with the local overrides. Recomputed only when the
     * registration itself changes, so a request pays one map lookup rather than re-deriving on every call.
     */
    private runtime;
    /**
     * An application may have several registered redirect URIs. The one belonging to this deployment is
     * the one pointing at the callback route this process actually serves — which is all the SDK can
     * know, since a service behind a proxy cannot see its own public origin. When that is still
     * ambiguous the choice is arbitrary, so it says so and the deploy is expected to pin `redirectUri`.
     */
    private callbackRedirectUri;
    /**
     * A registered redirect uri that does not point at the callback route is the classic silent failure:
     * login works, the browser comes back to nothing. It stays a warning rather than an error because a
     * reverse proxy is perfectly entitled to rewrite the path in front of the service.
     */
    private warnOnRedirectUriMismatch;
    /**
     * A handle identity has rejected is remembered as dead rather than merely dropped. That keeps a
     * forged or replayed cookie from buying a fresh round trip to identity on every retry — without it
     * an unknown hash reads as active again immediately, and the application becomes an amplifier
     * pointed at the one service every other application also depends on.
     */
    private forgetOnInvalidSession;
    private revoke;
    private evictTokens;
    /** Records the failure at warn level before it propagates; browser-flow rejections are expected traffic, not defects */
    private logged;
}
