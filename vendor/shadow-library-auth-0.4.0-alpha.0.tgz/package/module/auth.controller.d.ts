import { ContextService } from '@shadow-library/fastify';
import { AppSessionService } from './app-session.service.js';
import { AuthCallbackQuery, AuthLoginQuery, AuthLogoutResponse, AuthSessionResponse, AuthStepUpQuery, BackchannelLogoutBody, BackchannelLogoutResponse } from './auth.dto.js';
import { AuthRoutePaths } from './config.js';
/** Applies the resolved paths to the controller; must run before the module registry scans the class */
export declare function configureAuthRoutes(resolved: AuthRoutePaths): void;
export declare class AuthController {
    private readonly sessions;
    private readonly context;
    private readonly logger;
    constructor(sessions: AppSessionService, context: ContextService);
    /** Starts the login: PKCE, `state`, `nonce` and `resource` out, the transient state into its own cookie */
    login(query: AuthLoginQuery): Promise<void>;
    /** Redeems the code for an opaque app-session handle and puts it in this application's own cookie */
    callback(query: AuthCallbackQuery): Promise<void>;
    /**
     * Ends this application's session. The central identity session survives it, unless a post-logout
     * redirect is configured and the browser is handed on to identity's RP-initiated logout.
     */
    logout(): Promise<AuthLogoutResponse | undefined>;
    /**
     * Accepts identity's back-channel logout notice and drops every local session of that user along
     * with their cached tokens. Answers 200 even when nothing matched — the notice is about the
     * identity session, and this application may simply never have had one for it.
     */
    backchannelLogout(body: BackchannelLogoutBody): Promise<BackchannelLogoutResponse>;
    /** Lets a browser client discover its login state without ever parsing — or seeing — a token */
    session(): Promise<AuthSessionResponse>;
    /**
     * The step-up landing point. It first tries to *claim* an existing step-up — the user may already
     * have satisfied identity elsewhere — and only prompts when there is nothing to claim.
     *
     * Both failures lead back to the prompt, but for opposite reasons, so each gets its own marker to
     * keep the bounce from becoming a loop. `claimed` says a prompt has already been answered and there
     * was still nothing to claim, which is terminal. `retried` says the step-up existed but named
     * another beneficiary (D-19) — a claim can never fix that, only a fresh prompt carrying this
     * application's intent can, and it gets exactly one.
     */
    stepUp(query: AuthStepUpQuery): Promise<void>;
    private claim;
    /** Carries both markers forward, so neither failure can bounce the browser more than once each */
    private promptUrl;
    private cookies;
    private send;
}
