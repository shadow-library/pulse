var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthInitializer_1, AuthModule_1;
/**
 * Importing npm packages
 */
import { Inject, Injectable, Module } from '@shadow-library/app';
import { Logger } from '@shadow-library/common';
import { ContextService, FASTIFY_INSTANCE, FastifyModule } from '@shadow-library/fastify';
/**
 * Importing user defined packages
 */
import { NAMESPACE } from '../constants.js';
import { AuthClient } from '../lib/auth-client.js';
import { AppSessionService } from './app-session.service.js';
import { AuthGuard } from './auth-guard.js';
import { AuthController, configureAuthRoutes } from './auth.controller.js';
import { resolveAuthClientConfig, resolveAuthRoutes, resolveBrowserAuthConfig } from './config.js';
import { extendContextWithAuth } from './context.js';
/**
 * Declaring the constants
 *
 * Import `AuthModule.forRoot(...)` inside `FastifyModule.forRoot({ imports: [...] })` and the service
 * is done: the guard middleware registers against the HTTP routes, the browser-facing auth
 * controllers come with it, and on startup the module extends the app's `ContextService` with
 * principal accessors, validates the configured scopes against discovery, pushes the role catalog
 * when one is declared (roles live in code, not in hand-run admin calls), and loads the
 * admin-configured service-access rules that decide which M2M callers may reach which routes.
 */
const AUTH_CONFIG = Symbol('shadow-library:auth-config');
const BROWSER_CONFIG = Symbol('shadow-library:auth-browser-config');
/** OIDC Back-Channel Logout posts form-encoded, which Fastify does not parse out of the box */
const FORM_CONTENT_TYPE = 'application/x-www-form-urlencoded';
let AuthInitializer = AuthInitializer_1 = class AuthInitializer {
    client;
    sessions;
    context;
    config;
    browser;
    fastify;
    logger = Logger.getLogger(NAMESPACE, AuthInitializer_1.name);
    constructor(client, sessions, context, config, browser, fastify) {
        this.client = client;
        this.sessions = sessions;
        this.context = context;
        this.config = config;
        this.browser = browser;
        this.fastify = fastify;
    }
    async onModuleInit() {
        extendContextWithAuth(this.context);
        if (this.browser.enabled && this.browser.routes.backchannelLogout)
            this.registerFormParser();
        /**
         * Resolving the registration here is what makes a misconfiguration a boot failure rather than a
         * puzzling 401 on a user's first login: audience, redirect uri and granted scopes all come from
         * identity now, so this is the first moment the service can be told it is wrong.
         */
        if (this.browser.enabled)
            await this.sessions.warmUp();
        /** Never forced: overriding identity's destructive-sync guardrail on every boot would defeat it */
        if (this.config.roles)
            await this.client.syncRoles(this.config.roles);
        if (this.config.client)
            await this.client.loadServiceAccess();
        this.logger.info('auth module initialised', {
            appId: this.config.appId,
            rolesDeclared: Boolean(this.config.roles),
            serviceAccessLoaded: Boolean(this.config.client),
            browserFlow: this.browser.enabled,
        });
    }
    /** The service-access refresh runs on an interval, so it has to be handed back when the app stops */
    onModuleDestroy() {
        this.client.stop();
    }
    /** Left alone when the application already parses forms; the SDK is a guest in someone else's server */
    registerFormParser() {
        if (this.fastify.hasContentTypeParser(FORM_CONTENT_TYPE))
            return;
        this.fastify.addContentTypeParser(FORM_CONTENT_TYPE, { parseAs: 'string' }, (_request, body, done) => done(null, Object.fromEntries(new URLSearchParams(body))));
        this.logger.debug('registered a form-encoded body parser for the back-channel logout route');
    }
};
AuthInitializer = AuthInitializer_1 = __decorate([
    Injectable(),
    __param(3, Inject(AUTH_CONFIG)),
    __param(4, Inject(BROWSER_CONFIG)),
    __param(5, Inject(FASTIFY_INSTANCE)),
    __metadata("design:paramtypes", [AuthClient,
        AppSessionService,
        ContextService, Object, Object, Object])
], AuthInitializer);
let AuthModule = AuthModule_1 = class AuthModule {
    static forRoot(options = {}) {
        const config = resolveAuthClientConfig(options);
        const routes = resolveAuthRoutes(options.routes);
        const browser = resolveBrowserAuthConfig(config, routes, options.browser);
        const client = new AuthClient(config);
        const sessions = new AppSessionService(client, browser);
        /** Route metadata is settled before the registry scans the controller, so this must happen here */
        if (browser.enabled)
            configureAuthRoutes(routes);
        /**
         * Handed over through factories rather than `useValue`, because `@Module` deep-freezes its
         * metadata: a value provider would freeze these live objects along with it, and a frozen client
         * can no longer cache its own discovery document.
         */
        return {
            module: AuthModule_1,
            imports: [FastifyModule],
            controllers: browser.enabled ? [AuthGuard, AuthController] : [AuthGuard],
            providers: [
                { token: AuthClient, useFactory: () => client },
                { token: AppSessionService, useFactory: () => sessions },
                { token: AUTH_CONFIG, useFactory: () => config },
                { token: BROWSER_CONFIG, useFactory: () => browser },
                { token: AuthInitializer, useClass: AuthInitializer },
            ],
            exports: [AuthClient, AppSessionService],
        };
    }
};
AuthModule = AuthModule_1 = __decorate([
    Module({})
], AuthModule);
export { AuthModule };
