/**
 * Defining types
 */
/** Everything an in-flight login needs to survive the round trip to identity and back */
export interface LoginState {
    state: string;
    nonce: string;
    codeVerifier: string;
    returnTo: string;
}
/** A login may stay in flight for ten minutes; the cookie carries the same deadline it enforces */
export declare const LOGIN_STATE_TTL_SECONDS = 600;
/** Encodes the in-flight login into the value the transient cookie carries */
export declare function encodeLoginState(state: LoginState, ttlSeconds?: number): string;
/**
 * Reads the login back out of the cookie. Cookies are attacker-influenced input, so every failure —
 * junk, truncation, an elapsed deadline — answers the same `null` as no cookie at all, and the
 * callback then fails closed on a login it cannot find.
 */
export declare function decodeLoginState(value: string | undefined): LoginState | null;
/** Constant-time comparison of the callback's `state` against the one the cookie carried */
export declare function matchesState(expected: string, received: string): boolean;
