/**
 * Importing npm packages
 */
import { DynamicModule } from '@shadow-library/app';
/**
 * Importing user defined packages
 */
import './config.js';
import { type RelyingPartyConfig } from '../rp/relying-party.js';
/**
 * Defining types
 */
/** The issuer falls back to the `AUTH_ISSUER` environment config when not passed in code */
export type RelyingPartyModuleOptions = Omit<RelyingPartyConfig, 'issuer'> & {
    issuer?: string;
};
/**
 * Declaring the constants
 *
 * **For third-party and external consumers only.** A Shadow app imports `AuthModule.forRoot()` and
 * gets first-party login end to end; importing this module instead reintroduces the token pair D-18
 * exists to remove. See `RelyingParty` for the full reasoning.
 */
export declare class RelyingPartyModule {
    static forRoot(options: RelyingPartyModuleOptions): DynamicModule;
}
