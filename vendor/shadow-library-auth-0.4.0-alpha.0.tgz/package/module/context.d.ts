/**
 * Importing npm packages
 */
import { ContextService } from '@shadow-library/fastify';
/**
 * Importing user defined packages
 */
import { type AuthPrincipal } from '../interfaces.js';
/**
 * Defining types
 */
declare module '@shadow-library/fastify' {
    interface ContextExtension {
        /** Returns the principal the auth guard resolved for the current request; throws 401 when the route ran unauthenticated */
        getAuthPrincipal(): AuthPrincipal;
        /** Returns the principal for the current request, or `null` on unauthenticated routes */
        getAuthPrincipalOrNull(): AuthPrincipal | null;
    }
    /** Surfaces the extension methods on the class type (`implements` alone does not add members) */
    interface ContextService extends ContextExtension {
    }
}
/**
 * Declaring the constants
 *
 * The principal lives in the request-scoped context store, keyed by a module-private symbol; the
 * only supported reads are the `getAuthPrincipal*` methods installed onto the app's
 * `ContextService` when `AuthModule` boots.
 */
export declare const AUTH_PRINCIPAL: unique symbol;
/** Installs the auth accessor methods onto the application's context service */
export declare function extendContextWithAuth(context: ContextService): void;
