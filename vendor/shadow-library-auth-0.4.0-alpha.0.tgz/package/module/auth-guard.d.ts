/**
 * Importing npm packages
 */
import { type HandlerMetadata } from '@shadow-library/app';
import { ContextService } from '@shadow-library/fastify';
import { AuthClient } from '../lib/auth-client.js';
import { AppSessionService } from './app-session.service.js';
/**
 * Defining types
 */
export interface GuardedRequest {
    headers: Record<string, string | string[] | undefined>;
    /** Path and query of the current request; used verbatim as the `return_to` of a login or step-up bounce */
    url?: string;
}
/** The subset of the framework reply the guard needs to bounce a browser instead of erroring at it */
export interface GuardedResponse {
    header(name: string, value: string | string[]): unknown;
    redirect(url: string, statusCode?: number): unknown;
}
export type AuthGuardHandler = (request: GuardedRequest, response?: GuardedResponse) => Promise<unknown>;
export declare class AuthGuard {
    private readonly client;
    private readonly context;
    private readonly sessions?;
    private readonly logger;
    constructor(client: AuthClient, context: ContextService, sessions?: AppSessionService | undefined);
    /** The router caches generated handlers by metadata alone; namespacing avoids colliding with other generating middlewares on the same route */
    cacheKey(metadata: HandlerMetadata): string;
    generate(metadata: HandlerMetadata): AuthGuardHandler | undefined;
    private authenticate;
    private authorize;
    private checkPermission;
    /**
     * Turns the two recoverable failures into the move that actually resolves them. A browser gets
     * bounced — to login when its session died, to step-up when the route needs `AAL2` — while every
     * other caller gets a status it can branch on. Nothing here ever falls through as anonymous.
     */
    private recover;
    /**
     * Fastify skips the route handler only once the reply has finished writing, and a hook that merely
     * *returns* the reply does not reliably get there first — the handler then runs unauthenticated and
     * the error handler tries to write a response that has already gone out. Awaiting the redirect is
     * what makes the bounce terminal.
     */
    private bounce;
    /** Warn-level trail for rejected credentials; the response stays a generic 401 */
    private unauthenticated;
    /** Warn-level trail for denied requests; the response stays a generic 403 */
    private denied;
}
