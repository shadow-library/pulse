var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var RelyingPartyModule_1;
/**
 * Importing npm packages
 */
import { Module } from '@shadow-library/app';
import { Config } from '@shadow-library/common';
/**
 * Importing user defined packages
 */
import './config.js';
import { RelyingParty } from '../rp/relying-party.js';
/**
 * Declaring the constants
 *
 * **For third-party and external consumers only.** A Shadow app imports `AuthModule.forRoot()` and
 * gets first-party login end to end; importing this module instead reintroduces the token pair D-18
 * exists to remove. See `RelyingParty` for the full reasoning.
 */
let RelyingPartyModule = RelyingPartyModule_1 = class RelyingPartyModule {
    static forRoot(options) {
        const relyingParty = new RelyingParty({ ...options, issuer: options.issuer ?? Config.get('auth.issuer') });
        return {
            module: RelyingPartyModule_1,
            providers: [{ token: RelyingParty, useValue: relyingParty }],
            exports: [RelyingParty],
        };
    }
};
RelyingPartyModule = RelyingPartyModule_1 = __decorate([
    Module({})
], RelyingPartyModule);
export { RelyingPartyModule };
