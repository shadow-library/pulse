import { AuthGuardErrorCode } from './errors.js';
/**
 * Declaring the constants
 *
 * The principal lives in the request-scoped context store, keyed by a module-private symbol; the
 * only supported reads are the `getAuthPrincipal*` methods installed onto the app's
 * `ContextService` when `AuthModule` boots.
 */
export const AUTH_PRINCIPAL = Symbol('shadow-library:auth-principal');
/** Installs the auth accessor methods onto the application's context service */
export function extendContextWithAuth(context) {
    context.extend({
        getAuthPrincipal() {
            const principal = this.get(AUTH_PRINCIPAL);
            if (!principal)
                throw AuthGuardErrorCode.IAM_001.create();
            return principal;
        },
        getAuthPrincipalOrNull() {
            return this.get(AUTH_PRINCIPAL);
        },
    });
}
