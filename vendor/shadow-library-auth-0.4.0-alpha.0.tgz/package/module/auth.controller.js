var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthController_1;
/**
 * Importing npm packages
 */
import { Controller, EnableIf, Handler } from '@shadow-library/app';
import { AppError, Logger } from '@shadow-library/common';
import { Body, ContextService, Get, HttpController, Post, Query, RespondFor } from '@shadow-library/fastify';
/**
 * Importing user defined packages
 */
import { NAMESPACE } from '../constants.js';
import { AuthErrorCode } from '../errors.js';
import { AppSessionService } from './app-session.service.js';
import { AuthCallbackQuery, AuthLoginQuery, AuthLogoutResponse, AuthSessionResponse, AuthStepUpQuery, BackchannelLogoutBody, BackchannelLogoutResponse } from './auth.dto.js';
import { parseCookies } from './cookie.js';
import { AuthGuardErrorCode } from './errors.js';
/**
 * Declaring the constants
 *
 * The browser-facing surface a consuming service inherits rather than writes. Paths and enablement
 * are resolved once by `AuthModule.forRoot()` and stamped onto this class before the framework scans
 * it: `EnableIf` reads the registry below and any overridden path is written over the default the
 * decorators declared. That is why the registry is module-scoped mutable state — route metadata is
 * settled at class-definition time, long before a provider could be injected to supply it.
 *
 * Cookies are read off the raw request rather than through `@Cookie()` on purpose: that decorator
 * pulls in the optional `@fastify/cookie` peer, and needing an extra install would break the promise
 * that `AuthModule.forRoot()` plus environment variables is the entire integration.
 */
const ROUTE_HANDLERS = [
    ['login', 'login'],
    ['callback', 'callback'],
    ['logout', 'logout'],
    ['backchannelLogout', 'backchannelLogout'],
    ['session', 'session'],
    ['stepUp', 'stepUp'],
];
let routes = null;
const isEnabled = (route) => Boolean(routes?.[route]);
/** 302 keeps the browser's method on a redirect the user follows interactively */
const FOUND = 302;
/** Applies the resolved paths to the controller; must run before the module registry scans the class */
export function configureAuthRoutes(resolved) {
    routes = resolved;
    Controller({ path: resolved.basePath })(AuthController);
    for (const [route, handler] of ROUTE_HANDLERS) {
        const path = resolved[route];
        const descriptor = Object.getOwnPropertyDescriptor(AuthController.prototype, handler);
        if (path && descriptor)
            Handler({ path })(AuthController.prototype, handler, descriptor);
    }
}
let AuthController = AuthController_1 = class AuthController {
    sessions;
    context;
    logger = Logger.getLogger(NAMESPACE, AuthController_1.name);
    constructor(sessions, context) {
        this.sessions = sessions;
        this.context = context;
    }
    /** Starts the login: PKCE, `state`, `nonce` and `resource` out, the transient state into its own cookie */
    async login(query) {
        const response = this.context.getResponse();
        const redirect = await this.sessions.beginLogin(query.return_to);
        this.send(response, redirect.cookies, redirect.url);
    }
    /** Redeems the code for an opaque app-session handle and puts it in this application's own cookie */
    async callback(query) {
        if (query.error)
            throw AuthErrorCode.EXCHANGE_FAILED.create({ reason: `identity refused the authorization: ${query.error_description ?? query.error}` });
        const result = await this.sessions.completeLogin(query, this.cookies());
        this.send(this.context.getResponse(), result.cookies, result.returnTo);
    }
    /**
     * Ends this application's session. The central identity session survives it, unless a post-logout
     * redirect is configured and the browser is handed on to identity's RP-initiated logout.
     */
    async logout() {
        const response = this.context.getResponse();
        const cleared = await this.sessions.logout(this.sessions.readHandle(this.cookies()));
        const redirectTo = await this.sessions.endSessionUrl();
        this.send(response, cleared, redirectTo);
        return redirectTo ? undefined : { success: true };
    }
    /**
     * Accepts identity's back-channel logout notice and drops every local session of that user along
     * with their cached tokens. Answers 200 even when nothing matched — the notice is about the
     * identity session, and this application may simply never have had one for it.
     */
    async backchannelLogout(body) {
        await this.sessions.handleBackchannelLogout(body.logout_token);
        return { success: true };
    }
    /** Lets a browser client discover its login state without ever parsing — or seeing — a token */
    async session() {
        const handle = this.sessions.readHandle(this.cookies());
        if (!handle)
            throw AuthGuardErrorCode.IAM_001.create();
        const principal = await this.sessions.resolvePrincipal(handle);
        return { sub: principal.sub, scopes: principal.scopes, org: principal.org, aal: principal.aal, clientId: principal.clientId };
    }
    /**
     * The step-up landing point. It first tries to *claim* an existing step-up — the user may already
     * have satisfied identity elsewhere — and only prompts when there is nothing to claim.
     *
     * Both failures lead back to the prompt, but for opposite reasons, so each gets its own marker to
     * keep the bounce from becoming a loop. `claimed` says a prompt has already been answered and there
     * was still nothing to claim, which is terminal. `retried` says the step-up existed but named
     * another beneficiary (D-19) — a claim can never fix that, only a fresh prompt carrying this
     * application's intent can, and it gets exactly one.
     */
    async stepUp(query) {
        const handle = this.sessions.readHandle(this.cookies());
        if (!handle)
            throw AuthGuardErrorCode.IAM_001.create();
        const returnTo = this.sessions.resolveReturnTo(query.return_to);
        const outcome = await this.claim(handle, query);
        const target = outcome === 'claimed' ? returnTo : await this.promptUrl(returnTo, outcome, query);
        this.send(this.context.getResponse(), [], target);
    }
    async claim(handle, query) {
        return this.sessions
            .claimElevation(handle)
            .then(() => 'claimed')
            .catch((error) => {
            if (AppError.is(error, AuthErrorCode.ELEVATION_INTENT_MISMATCH)) {
                if (query.retried)
                    throw error;
                this.logger.warn('the step-up named another beneficiary; restarting the prompt with this application intent');
                return 'mismatch';
            }
            if (query.claimed)
                throw error;
            this.logger.debug('no step-up left to claim; handing the browser to identity');
            return 'absent';
        });
    }
    /** Carries both markers forward, so neither failure can bounce the browser more than once each */
    promptUrl(returnTo, outcome, query) {
        const markers = [outcome === 'absent' || query.claimed ? 'claimed=1' : '', outcome === 'mismatch' || query.retried ? 'retried=1' : ''].filter(Boolean);
        return this.sessions.identityStepUpUrl(`${this.sessions.stepUpUrl(returnTo)}&${markers.join('&')}`);
    }
    cookies() {
        return parseCookies(this.context.getRequest().headers.cookie);
    }
    send(response, cookies, redirectTo) {
        for (const cookie of cookies)
            response.header('set-cookie', cookie);
        if (redirectTo)
            response.redirect(redirectTo, FOUND);
    }
};
__decorate([
    Get('/login'),
    EnableIf(() => isEnabled('login')),
    __param(0, Query()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [AuthLoginQuery]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "login", null);
__decorate([
    Get('/callback'),
    EnableIf(() => isEnabled('callback')),
    __param(0, Query()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [AuthCallbackQuery]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "callback", null);
__decorate([
    Post('/logout'),
    EnableIf(() => isEnabled('logout')),
    RespondFor(200, AuthLogoutResponse),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logout", null);
__decorate([
    Post('/backchannel-logout'),
    EnableIf(() => isEnabled('backchannelLogout')),
    RespondFor(200, BackchannelLogoutResponse),
    __param(0, Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [BackchannelLogoutBody]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "backchannelLogout", null);
__decorate([
    Get('/session'),
    EnableIf(() => isEnabled('session')),
    RespondFor(200, AuthSessionResponse),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "session", null);
__decorate([
    Get('/step-up'),
    EnableIf(() => isEnabled('stepUp')),
    __param(0, Query()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [AuthStepUpQuery]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "stepUp", null);
AuthController = AuthController_1 = __decorate([
    HttpController('/auth'),
    __metadata("design:paramtypes", [AppSessionService,
        ContextService])
], AuthController);
export { AuthController };
