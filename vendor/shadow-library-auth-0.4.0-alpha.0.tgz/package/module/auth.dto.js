var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Importing npm packages
 */
import { Field, Schema } from '@shadow-library/class-schema';
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
/**
 * Declaring the constants
 *
 * The query and body shapes keep their wire names: `return_to`, `logout_token` and the OAuth error
 * parameters are spelled by their specifications, and renaming them here would only hide which
 * parameter a failure is actually about. Every query schema stays open to additional properties so a
 * future identity release can add one without this SDK rejecting the callback.
 */
let AuthLoginQuery = class AuthLoginQuery {
    /** Where to land once the login completes; validated against the redirect allow-list, never trusted */
    return_to;
};
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthLoginQuery.prototype, "return_to", void 0);
AuthLoginQuery = __decorate([
    Schema({ additionalProperties: true })
], AuthLoginQuery);
export { AuthLoginQuery };
let AuthCallbackQuery = class AuthCallbackQuery {
    code;
    state;
    /** Present instead of `code` when the user declined or identity refused the request */
    error;
    error_description;
};
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthCallbackQuery.prototype, "code", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthCallbackQuery.prototype, "state", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthCallbackQuery.prototype, "error", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthCallbackQuery.prototype, "error_description", void 0);
AuthCallbackQuery = __decorate([
    Schema({ additionalProperties: true })
], AuthCallbackQuery);
export { AuthCallbackQuery };
let AuthStepUpQuery = class AuthStepUpQuery {
    return_to;
    /** Set on the way back from identity, so a step-up that still cannot be claimed fails instead of looping */
    claimed;
    /** Set after a prompt was restarted for an intent mismatch, so a second mismatch fails instead of looping */
    retried;
};
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthStepUpQuery.prototype, "return_to", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthStepUpQuery.prototype, "claimed", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthStepUpQuery.prototype, "retried", void 0);
AuthStepUpQuery = __decorate([
    Schema({ additionalProperties: true })
], AuthStepUpQuery);
export { AuthStepUpQuery };
let BackchannelLogoutBody = class BackchannelLogoutBody {
    logout_token;
};
__decorate([
    Field(),
    __metadata("design:type", String)
], BackchannelLogoutBody.prototype, "logout_token", void 0);
BackchannelLogoutBody = __decorate([
    Schema()
], BackchannelLogoutBody);
export { BackchannelLogoutBody };
let AuthSessionResponse = class AuthSessionResponse {
    sub;
    scopes;
    org;
    /** `AAL2` only while a step-up grant for this application's audience is live */
    aal;
    clientId;
};
__decorate([
    Field(),
    __metadata("design:type", String)
], AuthSessionResponse.prototype, "sub", void 0);
__decorate([
    Field(() => [String]),
    __metadata("design:type", Array)
], AuthSessionResponse.prototype, "scopes", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthSessionResponse.prototype, "org", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthSessionResponse.prototype, "aal", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthSessionResponse.prototype, "clientId", void 0);
AuthSessionResponse = __decorate([
    Schema()
], AuthSessionResponse);
export { AuthSessionResponse };
let AuthLogoutResponse = class AuthLogoutResponse {
    success;
    /** Set when identity's RP-initiated logout should be visited next */
    redirectTo;
};
__decorate([
    Field(),
    __metadata("design:type", Boolean)
], AuthLogoutResponse.prototype, "success", void 0);
__decorate([
    Field({ optional: true }),
    __metadata("design:type", String)
], AuthLogoutResponse.prototype, "redirectTo", void 0);
AuthLogoutResponse = __decorate([
    Schema()
], AuthLogoutResponse);
export { AuthLogoutResponse };
let BackchannelLogoutResponse = class BackchannelLogoutResponse {
    success;
};
__decorate([
    Field(),
    __metadata("design:type", Boolean)
], BackchannelLogoutResponse.prototype, "success", void 0);
BackchannelLogoutResponse = __decorate([
    Schema()
], BackchannelLogoutResponse);
export { BackchannelLogoutResponse };
