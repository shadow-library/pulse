/**
 * Importing npm packages
 */
import { Config, Logger, utils } from '@shadow-library/common';
/**
 * Importing user defined packages
 */
import { NAMESPACE } from '../constants.js';
import { assertValidCookieName } from './cookie.js';
import { LOGIN_STATE_TTL_SECONDS } from './login-state.js';
/**
 * Declaring the constants
 *
 * A steady-state deploy configures three things: `AUTH_ISSUER`, `AUTH_APP_ID`, and one credential —
 * a projected service-account token at `AUTH_CLIENT_ASSERTION_PATH` in-cluster, or a static
 * `AUTH_CLIENT_SECRET` outside it. Everything identity already stores about the application is read
 * back from it (D-21): the audience its tokens are addressed to, the redirect URIs an admin
 * registered, the scopes an admin granted, and the step-up endpoint from discovery. Restating those
 * in environment variables is what the old `AUTH_AUDIENCE` / `AUTH_REDIRECT_URI` / `AUTH_SCOPES` /
 * `AUTH_STEP_UP_URL` did, and they are gone rather than deprecated — a stale value in a deploy
 * silently overriding what identity says is worse than having no override at all. The escape hatch is
 * `browser: { … }` in code, where it is visible and reviewed.
 *
 * The rest tunes behaviour and has safe defaults. The one setting that can weaken security —
 * `AUTH_SESSION_COOKIE_SECURE` — announces itself in the logs when it is used.
 */
Config.load('auth.issuer');
/** Without it a production service cannot read its own registration back, and so cannot know its own audience */
Config.load('auth.app-id', { isProdRequired: true });
Config.load('auth.client.id');
Config.load('auth.client.secret');
Config.load('auth.client.assertion-path');
Config.load('auth.timeout', { validateType: 'number' });
Config.load('auth.app.refresh-seconds', { validateType: 'number', defaultValue: '300' });
Config.load('auth.service-access.refresh-seconds', { validateType: 'number', defaultValue: '300' });
Config.load('auth.strict-scopes', { validateType: 'boolean', defaultValue: 'false' });
Config.load('auth.browser-login', { validateType: 'boolean', defaultValue: 'true' });
Config.load('auth.session.cookie-name', { defaultValue: '__Host-shadow-session' });
Config.load('auth.session.cookie-secure', { validateType: 'boolean', defaultValue: 'true' });
Config.load('auth.session.cookie-same-site', { allowedValues: ['Lax', 'Strict', 'None'], defaultValue: 'Lax' });
Config.load('auth.session.cookie-domain');
Config.load('auth.post-login-redirect', { defaultValue: '/' });
Config.load('auth.post-logout-redirect');
Config.load('auth.allowed-redirects', { isArray: true });
const logger = Logger.getLogger(NAMESPACE, 'AuthConfig');
/** The login-state cookie shares the session cookie's name so both stand or fall on the same prefix rules */
const STATE_COOKIE_SUFFIX = '-login';
const DEFAULT_ROUTES = {
    basePath: '/auth',
    login: '/login',
    callback: '/callback',
    logout: '/logout',
    /**
     * Off by default. First-party revocation is pull-based: identity ends the central session and the
     * next mint from that handle fails, so it never sends a back-channel logout to an app-session
     * client — the route would sit there accepting nothing. It stays available for the third-party
     * `RelyingParty` path, where a logout token really is the only notice a consumer gets.
     */
    backchannelLogout: false,
    session: '/session',
    stepUp: '/step-up',
};
/** Fills any option not supplied in code from the corresponding `AUTH_*` environment config */
export function resolveAuthClientConfig(options = {}) {
    const issuer = options.issuer ?? Config.get('auth.issuer');
    const appId = options.appId ?? Config.get('auth.app-id') ?? undefined;
    /** The app id doubles as the OAuth client id, so a deploy names the application once and only once */
    let client = options.client;
    const clientId = Config.get('auth.client.id') || appId;
    if (!client && clientId) {
        client = { id: clientId, secret: Config.get('auth.client.secret') || undefined, assertionPath: Config.get('auth.client.assertion-path') || undefined };
    }
    const timeout = options.timeout ?? Config.get('auth.timeout');
    const app = { refreshSeconds: options.app?.refreshSeconds ?? Config.get('auth.app.refresh-seconds') };
    const serviceAccess = { refreshSeconds: options.serviceAccess?.refreshSeconds ?? Config.get('auth.service-access.refresh-seconds') };
    const strictScopes = options.strictScopes ?? Config.get('auth.strict-scopes');
    return { ...utils.object.omitKeys(options, ['browser', 'routes']), issuer, appId, client, timeout, app, serviceAccess, strictScopes };
}
export function resolveAuthRoutes(overrides = {}) {
    return { ...DEFAULT_ROUTES, ...overrides };
}
/**
 * Resolves the browser-facing half. It stays off without client credentials, because minting on a
 * browser's behalf is impossible without the application's own M2M credential — registering the
 * routes anyway would only hand callers a login that cannot complete.
 */
export function resolveBrowserAuthConfig(client, routes, options = {}) {
    const enabled = (options.enabled ?? Config.get('auth.browser-login')) && Boolean(client.client);
    const secure = options.cookieSecure ?? Config.get('auth.session.cookie-secure');
    const sameSite = options.cookieSameSite ?? Config.get('auth.session.cookie-same-site');
    const domain = options.cookieDomain ?? Config.get('auth.session.cookie-domain') ?? undefined;
    const cookieName = options.cookieName ?? Config.get('auth.session.cookie-name');
    const cookie = { path: '/', httpOnly: true, secure, sameSite, domain };
    if (enabled) {
        if (!secure)
            logger.warn('session cookies are configured without the Secure attribute; this is for plain-http development only and must never reach production');
        if (sameSite === 'None') {
            logger.warn('session cookies are configured with SameSite=None, which sends them on cross-site requests; the application must supply its own CSRF defence on every state-changing route');
        }
        assertValidCookieName(cookieName, cookie);
    }
    return {
        enabled,
        routes,
        redirectUri: options.redirectUri,
        scopes: options.scopes,
        stepUpUrl: options.stepUpUrl,
        postLoginRedirect: options.postLoginRedirect ?? Config.get('auth.post-login-redirect'),
        postLogoutRedirect: options.postLogoutRedirect ?? Config.get('auth.post-logout-redirect') ?? undefined,
        allowedRedirects: options.allowedRedirects ?? Config.get('auth.allowed-redirects') ?? [],
        validateScopes: options.validateScopes ?? true,
        cookieName,
        cookie,
        stateCookieName: `${cookieName}${STATE_COOKIE_SUFFIX}`,
        /**
         * The login-state cookie has to survive identity redirecting the browser back, which is a
         * cross-site top-level navigation — `Strict` would withhold it and no login could ever complete.
         * It is the one attribute the state cookie does not inherit.
         */
        stateCookie: { ...cookie, sameSite: sameSite === 'Strict' ? 'Lax' : sameSite, maxAge: LOGIN_STATE_TTL_SECONDS },
    };
}
