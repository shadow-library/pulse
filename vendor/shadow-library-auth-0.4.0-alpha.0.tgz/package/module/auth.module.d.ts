/**
 * Importing npm packages
 */
import { DynamicModule } from '@shadow-library/app';
import { AuthModuleOptions } from './config.js';
export declare class AuthModule {
    static forRoot(options?: AuthModuleOptions): DynamicModule;
}
