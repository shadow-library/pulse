export declare class SessionRegistry {
    private readonly logger;
    private readonly sessions;
    private readonly bySubject;
    /**
     * Revoked hashes and when they would have expired anyway. A revoked session must not simply be
     * forgotten: an unknown hash is treated as active on purpose, so deleting one would quietly hand
     * the cookie back its access.
     */
    private readonly revoked;
    register(handleHash: string, sub: string, expiresAt: number): void;
    /**
     * Whether this handle may still be presented. Unknown hashes answer `true`: a process that
     * restarted, or an instance that never served the login, must not log everybody out.
     */
    isActive(handleHash: string): boolean;
    /**
     * Records a handle as dead. Unlike `forget` this is remembered, which is what stops a rejected or
     * logged-out handle from reading as "unknown, therefore active" on the next request — and what
     * keeps a forged cookie from buying another round trip to identity on every retry.
     */
    revoke(handleHash: string): void;
    forget(handleHash: string): void;
    /** Ends every session this process knows of for one user; returns the hashes whose tokens must go */
    revokeSubject(sub: string): string[];
    private sweep;
}
