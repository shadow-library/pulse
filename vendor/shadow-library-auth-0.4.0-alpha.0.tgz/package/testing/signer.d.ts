/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
import { Jwk, JwtPayload } from '../interfaces.js';
/**
 * Defining types
 */
export interface TestSigner {
    kid: string;
    publicJwk: Jwk & {
        kid: string;
    };
    sign(claims: JwtPayload): Promise<string>;
}
/** Creates an ephemeral Ed25519 signer for unit tests; the public JWK is ready to publish in a JWKS */
export declare function createTestSigner(): Promise<TestSigner>;
