/**
 * Importing npm packages
 */
/**
 * Declaring the constants
 */
const encoder = new TextEncoder();
const encodeSegment = (value) => Buffer.from(JSON.stringify(value)).toString('base64url');
/** Creates an ephemeral Ed25519 signer for unit tests; the public JWK is ready to publish in a JWKS */
export async function createTestSigner() {
    const pair = (await crypto.subtle.generateKey('Ed25519', true, ['sign', 'verify']));
    const kid = crypto.randomUUID();
    const jwk = (await crypto.subtle.exportKey('jwk', pair.publicKey));
    const publicJwk = { ...jwk, kid, alg: 'EdDSA', use: 'sig' };
    const sign = async (claims) => {
        const signingInput = `${encodeSegment({ alg: 'EdDSA', typ: 'JWT', kid })}.${encodeSegment(claims)}`;
        const signature = await crypto.subtle.sign('Ed25519', pair.privateKey, encoder.encode(signingInput));
        return `${signingInput}.${Buffer.from(signature).toString('base64url')}`;
    };
    return { kid, publicJwk, sign };
}
