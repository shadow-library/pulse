/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
import { AppRegistration, FetchLike, JwtPayload, PrincipalKind, ServiceAccessRule } from '../interfaces.js';
/**
 * Defining types
 */
export interface TestIdPOptions {
    /** Overrides the issuer advertised in discovery; defaults to the bound server url */
    issuer?: string;
    /** When set, the token endpoint enforces these client credentials */
    clientId?: string;
    clientSecret?: string;
    accessTokenTtlSeconds?: number;
    /** Published as `scopes_supported`; left unset, discovery omits it and startup scope validation stands down */
    scopesSupported?: string[];
    /** How long an app session lives before its handle stops minting; defaults to an hour */
    appSessionTtlSeconds?: number;
    /**
     * What `GET /api/v1/apps/me` answers (D-21). Left unset, the mock publishes a registration derived
     * from `clientId`, so a consumer configured with nothing but issuer + app id + credential still boots.
     */
    app?: Partial<AppRegistration>;
}
export interface TestTokenInput {
    sub: string;
    kind?: PrincipalKind;
    audience?: string | string[];
    scopes?: string[];
    org?: string;
    sid?: string;
    clientId?: string;
    /** May be negative to mint already-expired tokens */
    ttlSeconds?: number;
    claims?: JwtPayload;
}
export interface TestPrincipalRef {
    kind: PrincipalKind;
    sub: string;
}
export interface CapturedCatalog {
    manifest: {
        permissions: unknown[];
        roles: unknown[];
    };
    authorization: string | null;
    /** Whether the caller asked identity to override its destructive-sync guardrail */
    forced: boolean;
}
export interface CapturedTokenRequest {
    body: Record<string, unknown>;
    authorization: string | null;
    contentType: string | null;
}
/** Which application and resource a step-up was granted for; an absent field matches anything */
export interface TestStepUpIntent {
    clientId?: string;
    resource?: string;
}
export interface TestLogoutTokenInput {
    sub?: string;
    sid?: string;
    claims?: JwtPayload;
}
export interface TestIdP {
    issuer: string;
    /** Mints a signed token with sensible claim defaults */
    issueToken(input: TestTokenInput): Promise<string>;
    /** Signs exactly the given claims — no defaults are applied */
    signToken(claims: JwtPayload): Promise<string>;
    /** Registers a single-use authorization code redeemable at the token endpoint */
    createAuthorizationCode(input: TestTokenInput & {
        nonce?: string;
    }): string;
    grantPermission(principal: TestPrincipalRef, organisationId: string, action: string): void;
    revokePermission(principal: TestPrincipalRef, organisationId: string, action: string): void;
    bumpAuthzVersion(): void;
    /** Replaces the signing key; previous public keys stay published, mirroring real rotation */
    rotateKeys(): Promise<void>;
    /** Makes an endpoint answer http 503 until re-enabled */
    setEndpointFailure(pathname: string, fail: boolean): void;
    getRequestCount(pathname: string): number;
    /**
     * Resolves once an endpoint has been called `count` times, so a test can wait for a scheduled
     * refresh to fire instead of sleeping for longer than it should take. It reports that the request
     * arrived, not that the SDK has finished applying the answer — assert on observable state after it.
     */
    waitForRequest(pathname: string, count?: number): Promise<void>;
    /**
     * A transport that drops the application's own M2M bearer, so a request arrives carrying nothing but
     * the session handle. Every app-session route then refuses it, which is the property the whole
     * first-party model rests on: possessing a handle grants nothing.
     */
    handleOnlyTransport(): FetchLike;
    /** Returns the most recent role-catalog sync the mock received, if any */
    getLastCatalog(): CapturedCatalog | undefined;
    /** Makes the catalog endpoint answer identity's destructive-sync refusal unless the caller forces past it */
    setCatalogGuardrail(refuse: boolean): void;
    /** Scopes a token exchange always drops, so a test can watch the SDK surface a silent narrowing */
    setUnexchangeableScopes(scopes: string[]): void;
    /** Configures the rules the `/api/v1/authz/service-access` endpoint returns */
    setServiceAccess(rules: ServiceAccessRule[]): void;
    /** The registration `GET /api/v1/apps/me` currently answers */
    getAppRegistration(): AppRegistration;
    /** Replaces it, so a test can watch an admin's grant change reach a running consumer */
    setAppRegistration(registration: Partial<AppRegistration>): void;
    /** Returns the most recent token-endpoint request the mock received, if any */
    getLastTokenRequest(): CapturedTokenRequest | undefined;
    /*!
     * First-party app sessions (D-18/D-19)
     */
    /**
     * Marks the user as having satisfied a step-up on the identity domain, so an elevation claim succeeds.
     * The intent names which application and resource the step-up was for (D-19) — a claim from anybody
     * else is refused with `AUTH_007`. Pass `true` for a step-up any claimant may spend, `false` to clear.
     */
    setSteppedUp(userId: string, intent: TestStepUpIntent | boolean): void;
    /** Ends the central identity session: every app session of that user starts answering `AUTH_005` */
    endIdentitySession(userId: string): void;
    /** Signs an OIDC back-channel logout token addressed to the configured client */
    issueLogoutToken(input: TestLogoutTokenInput): Promise<string>;
    /** How many app sessions are live, for asserting that a revocation actually reached identity */
    getAppSessionCount(): number;
    /** Returns the most recent mint request the app-session token endpoint received, if any */
    getLastMintRequest(): Record<string, unknown> | undefined;
    /** Returns the most recent elevation claim, so a test can assert which resource it named */
    getLastElevationRequest(): Record<string, unknown> | undefined;
    stop(): void;
}
/**
 * Spins an in-process mock identity provider: an ephemeral Ed25519 key, discovery + JWKS + token +
 * PDP endpoints on a random port. Consuming services integration-test their guards against it
 * without a running identity service.
 */
export declare function createTestIdP(options?: TestIdPOptions): Promise<TestIdP>;
