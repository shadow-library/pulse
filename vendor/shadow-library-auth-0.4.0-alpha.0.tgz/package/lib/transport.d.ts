/**
 * Importing npm packages
 */
import { type FetchLike } from '../interfaces.js';
/**
 * Defining types
 */
/**
 * Declaring the constants
 */
/** Mirrors `APIRequest.timeout()`'s positive-finite-milliseconds contract, but as configuration validation rather than a per-call guard */
export declare function assertValidTimeout(timeout: number | undefined): void;
/**
 * Wraps a transport so every request it makes is bounded by a total time budget via `AbortSignal.timeout`,
 * merging the deadline with any caller-supplied signal. A fresh deadline is armed per call, so the 401 retry
 * paths get the full budget each attempt rather than sharing one clock.
 */
export declare function withTimeout(fetchFn: FetchLike, timeout: number | undefined): FetchLike;
