import { type AuthClientCredential } from '../interfaces.js';
/**
 * Defining types
 */
export interface ClientAuthentication {
    /** Request headers carrying the credential, when it travels in one (HTTP Basic) */
    headers: Record<string, string>;
    /** Form parameters carrying the credential, when it travels in the body (client assertion, public client) */
    body: Record<string, string>;
}
export declare function buildClientAuthentication(client: AuthClientCredential): Promise<ClientAuthentication>;
/** Whether the credential can prove the application's identity, as every confidential grant requires */
export declare function isConfidential(client: AuthClientCredential | undefined): client is AuthClientCredential;
