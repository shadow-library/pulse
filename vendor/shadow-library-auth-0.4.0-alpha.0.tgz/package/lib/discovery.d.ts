import { DiscoveryDocument, FetchLike } from '../interfaces.js';
/**
 * Defining types
 */
/**
 * Declaring the constants
 *
 * The discovery document is immutable for the lifetime of a deployment, so it is fetched once per
 * process (singleflight) and cached indefinitely; endpoint changes ship as new deployments.
 */
export declare class DiscoveryClient {
    private readonly issuer;
    private readonly fetchFn;
    private readonly logger;
    private document;
    private inflight;
    constructor(issuer: string, fetchFn: FetchLike);
    get(): Promise<DiscoveryDocument>;
    private load;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
