/**
 * Importing npm packages
 */
import { type APIResponse } from '@shadow-library/common';
import { AppRegistration, AuthClientConfig, AuthPrincipal, CheckInput, CheckOptions, DiscoveryDocument, ExchangedToken, IntrospectionResult, LogoutTokenClaims, RoleCatalogManifest, RoleCatalogSyncOptions, RoleCatalogSyncResult, ServiceAccessRule, ServiceTokenOptions, TokenExchangeInput } from '../interfaces.js';
import { AppSessionClient } from './app-session-client.js';
/**
 * The consumer-facing auth client: offline token verification, PDP checks, M2M tokens, role
 * catalog sync, and admin-managed service-access rules. Designed as an injectable class —
 * `AuthModule.forRoot()` registers it under its own class token so application services take it
 * as an ordinary constructor dependency.
 */
export declare class AuthClient {
    private readonly config;
    private readonly logger;
    private readonly issuer;
    private readonly transport;
    private readonly timeout?;
    private readonly clockSkewSeconds;
    private readonly jwks;
    private readonly tokens;
    private readonly pdp;
    private readonly discovery;
    private readonly serviceAccess;
    private readonly apps;
    /** The first-party app-session protocol client; see `AppSessionClient` for why it is M2M-only */
    readonly appSessions: AppSessionClient;
    constructor(config: AuthClientConfig);
    /**
     * This application's registration at identity: audience, redirect URIs, and the scopes an admin has
     * granted it. Resolved on first use and refreshed on a TTL, so a grant change propagates without a
     * redeploy; the last good registration survives an identity outage.
     */
    getAppRegistration(): Promise<AppRegistration>;
    /**
     * The API resource this service's tokens must be addressed to. The explicit `audience` wins when one
     * is configured, which is the escape hatch for a deployment identity does not know the whole of.
     */
    getAudience(): Promise<string>;
    /** The issuer's discovery document, fetched once per process and cached for the deployment's lifetime */
    getDiscovery(): Promise<DiscoveryDocument>;
    /**
     * Fails the boot when a configured scope is absent from the issuer's published `scopes_supported`.
     * A typo would otherwise mint quietly — with the misspelt scope simply dropped — and only surface
     * as a puzzling 403 deep inside a request, so it is worth one startup round trip.
     */
    assertScopesSupported(scopes: string[]): Promise<void>;
    /** Verifies a bearer token offline against the issuer's JWKS and returns the resolved principal */
    verify(token: string): Promise<AuthPrincipal>;
    /**
     * Verifies an OIDC back-channel logout token (OpenID Connect Back-Channel Logout 1.0 §2.6). Unlike
     * an access token it is addressed to this *client*, not to this API, and the `events` claim plus
     * the absence of `nonce` are what separate it from an ID token replayed as a logout notice.
     */
    verifyLogoutToken(token: string): Promise<LogoutTokenClaims>;
    /** Asks the PDP whether the principal may perform the action; deny-by-default on any failure */
    check(input: CheckInput, options?: CheckOptions): Promise<boolean>;
    checkAll(inputs: CheckInput[], options?: CheckOptions): Promise<boolean[]>;
    /** Returns a cached client-credentials token for calling another service */
    getServiceToken(options?: ServiceTokenOptions): Promise<string>;
    /**
     * Exchanges the user's token for one addressed to another application, acting *as the user* (RFC
     * 8693, D-22). This is the only supported way to do that: forwarding the user's own token gives the
     * receiving API an audience that is not its own, and asserting the user in a header is forbidden
     * outright because a header is not a credential.
     *
     * The result is never cached. It belongs to one user, is short-lived, and its `exp` is capped by the
     * subject token's — caching it would key a per-user credential by resource and hand it to the wrong
     * caller the moment two users' requests overlap.
     */
    exchangeUserToken(input: TokenExchangeInput): Promise<ExchangedToken>;
    /**
     * Delegation is single-hop by protocol rule, and the check belongs client-side: a service that is
     * itself being called through an exchange must learn that from the token it holds, not from a round
     * trip to identity that fails for reasons it cannot distinguish from an outage.
     */
    private assertSingleHop;
    /** `fetch` with the service token injected and a single automatic retry on a stale-token 401 */
    fetch(url: string, init?: RequestInit, options?: ServiceTokenOptions): Promise<Response>;
    /**
     * Calls a named ecosystem service over the `svc://` scheme, which APIRequest resolves through
     * cluster DNS (or a `SERVICE_URL_<NAME>` override). A service token addressed to the service is
     * attached and a stale-token 401 triggers a single retry with a fresh token.
     */
    fetchService<T = unknown>(service: string, path: string, init?: RequestInit, options?: ServiceTokenOptions): Promise<APIResponse<T>>;
    /**
     * Declaratively replaces this application's role catalog in identity; requires service-account
     * credentials. The manifest is the complete truth — anything absent from it is deleted there — so
     * identity guards against a sync that would delete too much and answers `ROLE_SYNC_REFUSED`. That
     * refusal is deliberately its own error: a truncated manifest must not read as a transport blip.
     */
    syncRoles(manifest: RoleCatalogManifest, options?: RoleCatalogSyncOptions): Promise<RoleCatalogSyncResult>;
    /**
     * Loads the admin-configured service-access rules for this application from identity and schedules
     * their periodic refresh. Called by `AuthModule` at startup; until the first load succeeds, every
     * service-to-service caller is denied (deny-by-default), so a failure here aborts the boot rather
     * than being swallowed.
     */
    loadServiceAccess(): Promise<ServiceAccessRule[]>;
    /**
     * Re-fetches the rules out of band, as the scheduled refresh does. Never throws — the last good
     * rules stay in force through an identity outage, because the alternative is every service in the
     * fleet revoking every one of its M2M callers the moment identity blinks.
     */
    refreshServiceAccess(): Promise<ServiceAccessRule[]>;
    /** Whether an M2M caller may invoke the given route, per the rules loaded from identity */
    isServiceCallerAllowed(callerClientId: string, method: string, path: string): boolean;
    /** Releases the client's background timers; `AuthModule` calls it when the application shuts down */
    stop(): void;
    /**
     * Explicit fallback for opaque tokens; MUST NOT be used for routine verification. Introspection is
     * now caller-scoped — another client's token reads as `active: false` — so it can no longer be used
     * to probe tokens this application does not own.
     */
    introspect(token: string): Promise<IntrospectionResult>;
    /** RFC 7009 revocation; `tokenTypeHint` narrows the lookup when the token's kind is known */
    revoke(token: string, tokenTypeHint?: 'access_token' | 'refresh_token'): Promise<void>;
    /** Identity's own explanation, when it sent one — a guardrail refusal is only actionable with its reason */
    private readFailureReason;
    /** Discovery is the source of truth; the issuer-relative path stays only as a last resort for older deployments */
    private oauthEndpoint;
    /** Every `/oauth2/*` grant this client drives: form-encoded, authenticated by secret or SA assertion */
    private postToOAuthEndpoint;
    private identityToken;
    private identityTokenOptions;
    private identityResource;
    /** Where a browser goes to satisfy a step-up prompt; published by discovery rather than configured */
    getStepUpEndpoint(): Promise<string>;
    private expectations;
    private toPrincipal;
    private withBearer;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
