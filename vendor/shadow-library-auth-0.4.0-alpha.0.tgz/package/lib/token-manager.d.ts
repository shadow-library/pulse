import { AuthClientCredential, FetchLike, ServiceTokenOptions } from '../interfaces.js';
import { DiscoveryClient } from './discovery.js';
/**
 * Defining types
 */
export interface ServiceTokenManagerOptions {
    discovery: DiscoveryClient;
    fetchFn: FetchLike;
    client?: AuthClientCredential;
    refreshSkewSeconds?: number;
}
export declare class ServiceTokenManager {
    private readonly options;
    private readonly logger;
    private readonly cache;
    private readonly inflight;
    constructor(options: ServiceTokenManagerOptions);
    getToken(options?: ServiceTokenOptions): Promise<string>;
    invalidate(options?: ServiceTokenOptions): void;
    private cacheKey;
    private request;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
