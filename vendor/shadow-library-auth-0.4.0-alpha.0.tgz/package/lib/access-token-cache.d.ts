import { AppSessionToken } from '../interfaces.js';
/**
 * Defining types
 */
export interface AccessTokenKey {
    /** Hash of the session handle — the handle itself never becomes a map key */
    handleHash: string;
    audience: string;
    elevated: boolean;
    /** What the caller asks for. Entries are stored under what identity actually granted, never this */
    scope?: string;
}
/** The only representation of a handle the SDK is allowed to keep outside the cookie */
export declare function hashSessionHandle(handle: string): string;
export declare class AccessTokenCache {
    private readonly refreshSkewSeconds;
    private readonly maxEntries;
    private readonly logger;
    /** Keyed by granted scope; what a caller asked for never names an entry */
    private readonly entries;
    /** The requested-scope lookup: request key → the granted-scope entry that satisfies it */
    private readonly lookups;
    /** Secondary index so a logout, a revoked session, or a back-channel notice can evict in one step */
    private readonly bySession;
    constructor(refreshSkewSeconds?: number, maxEntries?: number);
    get(key: AccessTokenKey): AppSessionToken | undefined;
    /** `grantExpiresAt` is the elevation window in epoch milliseconds; entries never outlive it */
    set(key: AccessTokenKey, token: AppSessionToken, grantExpiresAt?: number): void;
    /** Drops every token minted for one session — used on logout, `SESSION_INVALID`, and back-channel logout */
    evictSession(handleHash: string): void;
    /** Drops only the elevated entries of a session, leaving its ordinary tokens in place */
    evictElevated(handleHash: string): void;
    clear(): void;
    /** Names the lookup a caller performs: everything but the scope, which is what it asked for */
    private requestId;
    /** Names the entry itself: everything but the scope, which is what identity actually granted */
    private grantedId;
    private prefix;
    private evict;
    /** Unhooks one request from an entry, taking the entry with it once nothing reaches it any more */
    private detach;
    /** Sweeps expired entries first and only then falls back to dropping the oldest insertion */
    private prune;
}
