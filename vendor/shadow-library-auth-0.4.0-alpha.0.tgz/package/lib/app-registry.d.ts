import { AppRegistration, FetchLike } from '../interfaces.js';
/**
 * Defining types
 */
export interface AppRegistryClientOptions {
    issuer: string;
    fetchFn: FetchLike;
    /** Supplies the application's own M2M bearer; `/apps/me` answers about whoever holds it */
    getToken: () => Promise<string>;
    /** Cross-checked against what identity answers, so a credential bound elsewhere fails loudly */
    appId?: string;
    refreshSeconds?: number;
}
export declare class AppRegistryClient {
    private readonly options;
    private readonly logger;
    private readonly refreshSeconds;
    private registration;
    private resolvedAt;
    private inflight;
    constructor(options: AppRegistryClientOptions);
    /** The registration, served from cache until its TTL elapses; concurrent callers share one resolve */
    get(): Promise<AppRegistration>;
    private resolve;
    private request;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
