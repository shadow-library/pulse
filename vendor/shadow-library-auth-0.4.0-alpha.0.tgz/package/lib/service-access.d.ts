import { FetchLike, ServiceAccessRule } from '../interfaces.js';
/**
 * Defining types
 */
export interface ServiceAccessClientOptions {
    issuer: string;
    fetchFn: FetchLike;
    /** Supplies the application's own M2M bearer, which must carry the `authz:check` scope */
    getToken: () => Promise<string>;
    refreshSeconds?: number;
}
export declare class ServiceAccessClient {
    private readonly options;
    private readonly logger;
    private readonly refreshSeconds;
    private rules;
    private inflight;
    private timer;
    constructor(options: ServiceAccessClientOptions);
    /**
     * The startup load. A failure propagates: until the rules are known every service-to-service caller
     * is denied, and a boot that swallows this would look healthy while refusing all of its peers.
     */
    load(): Promise<ServiceAccessRule[]>;
    /**
     * A refresh that never throws, so neither the interval nor a manual operator call can turn an
     * identity outage into a request-path failure. On any error the last good rules stay in force.
     */
    refresh(): Promise<ServiceAccessRule[]>;
    /** Whether an M2M caller may invoke the given route, per the rules last loaded from identity */
    isAllowed(callerClientId: string, method: string, path: string): boolean;
    /** Releases the refresh interval; without it a long-lived timer would outlive the application */
    stopRefresh(): void;
    private startRefresh;
    /** Concurrent callers — the interval and a request-path retry — share one round trip */
    private fetch;
    private request;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
