import { AppSession, AppSessionCreateInput, AppSessionElevation, AppSessionToken, AppSessionTokenInput, FetchLike } from '../interfaces.js';
/**
 * Defining types
 */
export interface AppSessionClientOptions {
    issuer: string;
    fetchFn: FetchLike;
    /** Supplies the application's own M2M bearer, which must carry the `app-session:manage` scope */
    getToken: () => Promise<string>;
    /** Drops that cached M2M token so a rejected credential is retried once with a fresh one */
    invalidateToken: () => void;
    /** Turns a narrowed mint into a thrown `SCOPE_NOT_GRANTED` rather than a warning */
    strictScopes?: boolean;
}
export declare class AppSessionClient {
    private readonly options;
    private readonly logger;
    private readonly baseUrl;
    constructor(options: AppSessionClientOptions);
    /** Redeems the authorization code for an opaque session handle; the handle is returned only once */
    createSession(input: AppSessionCreateInput): Promise<AppSession>;
    /** Mints an access token from the session handle, optionally from its live step-up grant */
    mintToken(input: AppSessionTokenInput): Promise<AppSessionToken>;
    /**
     * Spends the user's step-up on the identity domain into a grant for this app session and this
     * audience only. Answers `ELEVATION_REQUIRED` when the user has not stepped up yet.
     */
    claimElevation(sessionHandle: string, resource: string): Promise<AppSessionElevation>;
    /** Ends this application's session only; the central identity session is untouched */
    revokeSession(sessionHandle: string): Promise<void>;
    /**
     * Minting answers 200 with whatever scope survived filtering rather than refusing, so a caller that
     * never compares gets a token quietly missing the capability its API is about to check for. The
     * delta is always logged; `strictScopes` makes it fatal for deployments where a partial grant is
     * worse than an outright failure.
     */
    private assertScopesSurvived;
    /**
     * One round trip with a single retry reserved for the case where *our own* M2M token was the thing
     * rejected. A 401 that identity attributes to the handle is terminal — retrying with a fresh
     * service token would only ask the same question twice.
     */
    private request;
    private dispatch;
    private parse;
    private readError;
    private toError;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
