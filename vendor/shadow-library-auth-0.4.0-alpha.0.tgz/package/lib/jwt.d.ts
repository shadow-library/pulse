/**
 * Importing npm packages
 */
import { JwtPayload } from '../interfaces.js';
/**
 * Defining types
 */
export interface JwtHeader {
    alg?: string;
    typ?: string;
    kid?: string;
}
export interface DecodedJwt {
    header: JwtHeader;
    payload: JwtPayload;
    signingInput: Uint8Array;
    signature: Uint8Array;
}
export interface ClaimExpectations {
    issuer: string;
    audience: string;
    clockSkewSeconds: number;
    nonce?: string;
}
export declare function decodeJwt(token: string): DecodedJwt;
export declare function validateClaims(payload: JwtPayload, expected: ClaimExpectations): void;
export declare function verifyJwt(token: string, getKey: (kid: string) => Promise<CryptoKey>, expected: ClaimExpectations): Promise<JwtPayload>;
