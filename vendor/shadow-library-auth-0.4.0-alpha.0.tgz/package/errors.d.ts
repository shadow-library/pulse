/**
 * Importing npm packages
 */
import { ErrorCode } from '@shadow-library/common';
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
/**
 * Declaring the constants
 *
 * The SDK error catalog: keys create and throw `AppError`s directly. Call-site context travels in
 * the `data` payload (e.g. `{ reason }`), keeping the catalog message stable while structured
 * detail flows into logs. Transient transport failures use `unavailable` (retryable, 503); broken
 * configuration uses `internal` (a defect — masked outside logs).
 */
export declare class AuthErrorCode extends ErrorCode {
    /*!
     * Configuration Errors
     */
    /** The auth client configuration is invalid */
    static readonly CONFIG_INVALID: AuthErrorCode;
    /**
     * This application's registration could not be read back from identity. Until it resolves once the
     * SDK does not know its own audience, so the first failure aborts the boot; a later one keeps the
     * last good registration, because an outage must not change which tokens a service accepts.
     */
    static readonly APP_REGISTRATION_FAILED: AuthErrorCode;
    /*!
     * Token Verification Errors
     */
    /** The token algorithm is not in the allow-list */
    static readonly ALG_REJECTED: AuthErrorCode;
    /** The token is not addressed to this audience */
    static readonly AUDIENCE_MISMATCH: AuthErrorCode;
    /** The token was issued by an untrusted issuer */
    static readonly ISSUER_MISMATCH: AuthErrorCode;
    /** No published JWKS key matches the token's kid */
    static readonly KEY_UNKNOWN: AuthErrorCode;
    /** The token nonce does not match the expected nonce */
    static readonly NONCE_MISMATCH: AuthErrorCode;
    /** The token has expired */
    static readonly TOKEN_EXPIRED: AuthErrorCode;
    /** The token is malformed or its signature does not verify */
    static readonly TOKEN_INVALID: AuthErrorCode;
    /*!
     * OIDC Relying-Party Errors
     */
    /** OIDC discovery failed or answered with an inconsistent document */
    static readonly DISCOVERY_FAILED: AuthErrorCode;
    /** The authorization-code exchange failed */
    static readonly EXCHANGE_FAILED: AuthErrorCode;
    /** The token introspection request failed */
    static readonly INTROSPECTION_FAILED: AuthErrorCode;
    /** The token revocation request failed */
    static readonly REVOCATION_FAILED: AuthErrorCode;
    /*!
     * First-Party App Session Errors
     */
    /** An app-session endpoint was unreachable or answered in a way the SDK cannot interpret */
    static readonly APP_SESSION_FAILED: AuthErrorCode;
    /** The route needs an AAL2 token and no live elevation grant covers this app session and audience */
    static readonly ELEVATION_REQUIRED: AuthErrorCode;
    /**
     * The user did step up, but for a different application or resource, so this claim cannot spend it
     * (D-19: the step-up names its beneficiary, which is what closes the acquisition race). Distinct
     * from `ELEVATION_REQUIRED` because retrying the claim can never succeed — only a fresh prompt can.
     */
    static readonly ELEVATION_INTENT_MISMATCH: AuthErrorCode;
    /** The client holds no scope on the requested resource — a registration defect, never retryable */
    static readonly RESOURCE_NOT_ENTITLED: AuthErrorCode;
    /** The requested scope is not granted for this audience — a configuration defect, never retryable */
    static readonly SCOPE_NOT_GRANTED: AuthErrorCode;
    /** A configured scope is absent from the issuer's published `scopes_supported`; caught at startup so a typo cannot silently narrow every token */
    static readonly SCOPE_UNSUPPORTED: AuthErrorCode;
    /** The app-session handle is unknown, expired, revoked, owned by another client, or its identity session has ended */
    static readonly SESSION_INVALID: AuthErrorCode;
    /*!
     * Browser Flow Errors
     */
    /** The callback carried no `state`, or one that does not match the transient login state */
    static readonly LOGIN_STATE_INVALID: AuthErrorCode;
    /** The back-channel logout token failed validation */
    static readonly LOGOUT_TOKEN_INVALID: AuthErrorCode;
    /** A `return_to` or post-logout target failed the redirect allow-list */
    static readonly REDIRECT_NOT_ALLOWED: AuthErrorCode;
    /*!
     * Machine-to-Machine Errors
     */
    /** The policy decision point is unreachable or answered malformed */
    static readonly PDP_UNAVAILABLE: AuthErrorCode;
    /** The role-catalog sync was rejected or unreachable */
    static readonly ROLE_SYNC_FAILED: AuthErrorCode;
    /**
     * Identity's guardrail refused the manifest as too destructive — the signature of a truncated or
     * half-generated catalog. Distinct from `ROLE_SYNC_FAILED` so such a deploy fails loudly instead of
     * looking like a transport blip somebody retries past; never retryable, only correctable or forced.
     */
    static readonly ROLE_SYNC_REFUSED: AuthErrorCode;
    /** The service-access rules could not be loaded at startup */
    static readonly SERVICE_ACCESS_FAILED: AuthErrorCode;
    /** The RFC 8693 token exchange was rejected by identity or its endpoint was unreachable */
    static readonly TOKEN_EXCHANGE_FAILED: AuthErrorCode;
    /**
     * The SDK refused to attempt the exchange. Delegation is single-hop by protocol rule (D-22), so a
     * subject token that already carries `act` is rejected here rather than at identity — the caller
     * learns it is being called through an exchange instead of watching a round trip fail.
     */
    static readonly TOKEN_EXCHANGE_REFUSED: AuthErrorCode;
    /** The client-credentials token request failed */
    static readonly TOKEN_REQUEST_FAILED: AuthErrorCode;
}
