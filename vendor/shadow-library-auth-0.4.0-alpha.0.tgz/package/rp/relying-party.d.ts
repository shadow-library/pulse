import { AuthCacheOptions, AuthClientCredential, FetchLike, JwtPayload } from '../interfaces.js';
/**
 * Defining types
 */
export interface RelyingPartyConfig {
    issuer: string;
    client: AuthClientCredential;
    redirectUri: string;
    /** Defaults to `['openid']` */
    scopes?: string[];
    clockSkewSeconds?: number;
    cache?: AuthCacheOptions;
    /** Total time budget in milliseconds applied to every outbound request (discovery, JWKS, token exchange); unbounded when unset */
    timeout?: number;
    fetch?: FetchLike;
}
export interface AuthorizationUrlOptions {
    state?: string;
    nonce?: string;
    scopes?: string[];
    resource?: string;
}
export interface AuthorizationRequest {
    url: string;
    state: string;
    nonce: string;
    codeVerifier: string;
}
export interface CodeExchangeInput {
    code: string;
    codeVerifier: string;
    /** The nonce sent on the authorization request; the ID token is rejected when it does not match */
    nonce?: string;
}
export interface TokenSet {
    accessToken: string;
    tokenType: string;
    expiresIn: number;
    scope?: string;
    idToken?: string;
    refreshToken?: string;
    idTokenClaims?: JwtPayload;
}
/**
 * Injectable class: `RelyingPartyModule.forRoot()` registers it under its own class token so app
 * services take it as an ordinary constructor dependency. Third-party consumers only — see above.
 */
export declare class RelyingParty {
    private readonly config;
    private readonly logger;
    private readonly issuer;
    private readonly transport;
    private readonly discovery;
    private readonly jwks;
    constructor(config: RelyingPartyConfig);
    /** Builds the `/oauth2/authorize` redirect with PKCE (S256), `state`, and `nonce` */
    createAuthorizationUrl(options?: AuthorizationUrlOptions): Promise<AuthorizationRequest>;
    /** Exchanges the callback code, validating the ID token (signature, `iss`/`aud`/`exp`/`nonce`) */
    exchangeCode(input: CodeExchangeInput): Promise<TokenSet>;
    refresh(refreshToken: string): Promise<TokenSet>;
    /** RFC 6749 §2.3.1: the token endpoint takes form-encoded bodies, and Basic keeps the client secret out of the body entirely */
    private requestTokens;
    private validateIdToken;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
