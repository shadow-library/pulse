/**
 * Importing npm packages
 */
import { Logger, throwError } from '@shadow-library/common';
/**
 * Importing user defined packages
 */
import { NAMESPACE } from '../constants.js';
import { AuthErrorCode } from '../errors.js';
import { DiscoveryClient } from '../lib/discovery.js';
import { RemoteJwks } from '../lib/jwks.js';
import { verifyJwt } from '../lib/jwt.js';
import { assertValidTimeout, withTimeout } from '../lib/transport.js';
import { buildAuthorizationUrl } from './authorization-url.js';
import { createPkcePair, randomUrlSafeString } from './pkce.js';
/**
 * Declaring the constants
 *
 * The protocol core of an OIDC relying party: authorization URLs, PKCE, code exchange, ID-token
 * validation. Session-cookie management and back-channel logout are deliberately left to the
 * consuming app (see docs/sdk.md).
 *
 * **For third-party and external consumers only.** A Shadow app is first-party: it logs users in
 * through `AuthModule`'s browser routes, exchanges the code for an opaque app-session handle, and
 * holds no tokens at rest (D-18). Reaching for this class inside a Shadow app means reintroducing the
 * token pair that model exists to remove — and hand-writing the login, cookie and cache code
 * `AuthModule.forRoot()` already provides.
 */
const DEFAULT_SCOPES = ['openid'];
const DEFAULT_CLOCK_SKEW_SECONDS = 60;
const DEFAULT_JWKS_TTL_SECONDS = 300;
/**
 * Injectable class: `RelyingPartyModule.forRoot()` registers it under its own class token so app
 * services take it as an ordinary constructor dependency. Third-party consumers only — see above.
 */
export class RelyingParty {
    config;
    logger = Logger.getLogger(NAMESPACE, RelyingParty.name);
    issuer;
    transport;
    discovery;
    jwks;
    constructor(config) {
        this.config = config;
        if (!config.issuer || !URL.canParse(config.issuer))
            throw AuthErrorCode.CONFIG_INVALID.create({ reason: 'issuer must be a valid url' });
        if (!config.client?.id)
            throw AuthErrorCode.CONFIG_INVALID.create({ reason: 'client id is required' });
        if (!config.redirectUri || !URL.canParse(config.redirectUri))
            throw AuthErrorCode.CONFIG_INVALID.create({ reason: 'redirect uri must be a valid url' });
        assertValidTimeout(config.timeout);
        this.issuer = config.issuer.replace(/\/+$/, '');
        this.transport = withTimeout(config.fetch ?? ((url, init) => fetch(url, init)), config.timeout);
        this.discovery = new DiscoveryClient(this.issuer, this.transport);
        this.jwks = new RemoteJwks({ discovery: this.discovery, fetchFn: this.transport, ttlSeconds: config.cache?.jwksTtlSeconds ?? DEFAULT_JWKS_TTL_SECONDS });
    }
    /** Builds the `/oauth2/authorize` redirect with PKCE (S256), `state`, and `nonce` */
    async createAuthorizationUrl(options = {}) {
        const document = await this.discovery.get();
        const pkce = await createPkcePair();
        const state = options.state ?? randomUrlSafeString(16);
        const nonce = options.nonce ?? randomUrlSafeString(16);
        const scopes = options.scopes ?? this.config.scopes ?? DEFAULT_SCOPES;
        const url = buildAuthorizationUrl({
            authorizationEndpoint: document.authorization_endpoint,
            clientId: this.config.client.id,
            redirectUri: this.config.redirectUri,
            scopes,
            state,
            nonce,
            codeChallenge: pkce.challenge,
            resource: options.resource,
        });
        /** Never `state` or `nonce`: both are single-use secrets for as long as the flow is in flight */
        this.logger.debug('authorization url created', { scopes, resource: options.resource });
        return { url, state, nonce, codeVerifier: pkce.verifier };
    }
    /** Exchanges the callback code, validating the ID token (signature, `iss`/`aud`/`exp`/`nonce`) */
    async exchangeCode(input) {
        const body = { grant_type: 'authorization_code', code: input.code, redirect_uri: this.config.redirectUri, code_verifier: input.codeVerifier };
        const tokens = await this.requestTokens(body);
        if (tokens.idToken)
            tokens.idTokenClaims = await this.validateIdToken(tokens.idToken, input.nonce);
        this.logger.info('authorization code exchanged', { hasIdToken: Boolean(tokens.idToken) });
        this.logger.debug('id token claims resolved', { sub: tokens.idTokenClaims?.sub });
        return tokens;
    }
    async refresh(refreshToken) {
        return this.requestTokens({ grant_type: 'refresh_token', refresh_token: refreshToken });
    }
    /** RFC 6749 §2.3.1: the token endpoint takes form-encoded bodies, and Basic keeps the client secret out of the body entirely */
    async requestTokens(body) {
        const document = await this.discovery.get();
        const headers = { 'content-type': 'application/x-www-form-urlencoded' };
        if (this.config.client.secret)
            headers.authorization = `Basic ${Buffer.from(`${this.config.client.id}:${this.config.client.secret}`).toString('base64')}`;
        else
            body.client_id = this.config.client.id;
        this.logger.debug('requesting tokens', { url: document.token_endpoint, grantType: body.grant_type });
        const response = await this.transport(document.token_endpoint, { method: 'POST', headers, body: new URLSearchParams(body).toString() }).catch((error) => throwError(this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: `token request failed: ${error.message}` }))));
        if (!response.ok)
            throw this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: `token endpoint returned http ${response.status}` }));
        const payload = (await response.json());
        if (!payload.access_token || typeof payload.expires_in !== 'number')
            throw this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: 'malformed token endpoint response' }));
        return {
            accessToken: payload.access_token,
            tokenType: payload.token_type ?? 'Bearer',
            expiresIn: payload.expires_in,
            scope: payload.scope,
            idToken: payload.id_token,
            refreshToken: payload.refresh_token,
        };
    }
    validateIdToken(idToken, nonce) {
        const expectations = { issuer: this.issuer, audience: this.config.client.id, clockSkewSeconds: this.config.clockSkewSeconds ?? DEFAULT_CLOCK_SKEW_SECONDS, nonce };
        return verifyJwt(idToken, kid => this.jwks.getKey(kid), expectations);
    }
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    logged(error) {
        this.logger.error(error.message);
        return error;
    }
}
