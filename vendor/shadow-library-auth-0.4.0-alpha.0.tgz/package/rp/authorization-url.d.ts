/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
export interface AuthorizationUrlInput {
    authorizationEndpoint: string;
    clientId: string;
    redirectUri: string;
    scopes: string[];
    state: string;
    nonce: string;
    /** The RFC 7636 S256 challenge; the matching verifier stays server-side until the callback */
    codeChallenge: string;
    /** The API resource the resulting token should be addressed to; a scope is only minted for the resource that owns it */
    resource?: string;
    /** RFC 9470 step-up: the assurance level the authorization must reach before it returns */
    acrValues?: string[];
}
/**
 * Declaring the constants
 *
 * Shared by both flows so a third-party relying party and a first-party app session cannot drift
 * apart on what an authorization request looks like — only what they redeem the code for differs.
 */
export declare function buildAuthorizationUrl(input: AuthorizationUrlInput): string;
