import { DynamicModule } from '@shadow-library/app';
import { type DatabaseModuleAsyncOptions, type DatabaseModuleOptions } from './database.types.js';
export declare class DatabaseModule {
    static forRoot(options: DatabaseModuleOptions): DynamicModule;
    static forRootAsync(options: DatabaseModuleAsyncOptions): DynamicModule;
}
