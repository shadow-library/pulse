import { FactoryProvider, ModuleMetadata } from '@shadow-library/app';
import { type DrizzleConfig } from 'drizzle-orm';
import { type PgDatabase } from 'drizzle-orm/pg-core';
import { type RedisOptions } from 'ioredis';
import type Memcached from 'memcached';
import { Promisable } from 'type-fest';
declare module '@shadow-library/common' {
    interface ConfigRecords {
        'database.postgres.url'?: string;
        'database.postgres.max-connections'?: number;
        'database.postgres.lazy-connection': boolean;
        'database.redis.url'?: string;
        'database.memcache.hosts'?: string;
    }
}
export interface DatabaseRecords {
}
type ResolveType<K extends string, Fallback> = DatabaseRecords extends Record<K, infer T> ? T : Fallback;
export type PostgresClient = ResolveType<'postgres', PgDatabase<any>>;
export interface PostgresError {
    errno: string;
    detail: string;
    severity: string;
    schema: string;
    table: string;
    constraint: string;
    file: string;
    routine: string;
    code: 'ERR_POSTGRES_SERVER_ERROR';
}
export interface PostgresConnectionConfig {
    url: string;
    maxConnections?: number;
}
export interface PostgresConfig {
    factory: (config: DrizzleConfig, connection: PostgresConnectionConfig) => Promisable<PostgresClient>;
    constraintErrorMap?: Record<string, Error>;
    lazyConnection?: boolean;
}
export interface RedisConfig {
    url?: string;
    options?: RedisOptions;
}
export interface MemcacheConfig {
    hosts?: string;
    options?: Memcached.options;
}
export interface DatabaseModuleOptions {
    postgres?: PostgresConfig;
    redis?: boolean | RedisConfig;
    memcache?: boolean | MemcacheConfig;
}
export interface DatabaseModuleAsyncOptions extends Pick<ModuleMetadata, 'imports'>, Pick<FactoryProvider, 'inject'> {
    useFactory: (...args: unknown[]) => Promisable<DatabaseModuleOptions>;
}
export {};
