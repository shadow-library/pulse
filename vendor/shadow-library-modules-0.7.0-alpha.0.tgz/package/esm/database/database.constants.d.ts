export declare const DATABASE_MODULE_OPTIONS: unique symbol;
export declare const LOGGER_NAMESPACE = "@shadow-library/modules/database";
export declare const DEFAULT_CONFIGS: {
    readonly 'database.postgres.url': {
        readonly defaultValue: "postgresql://postgres:postgres@localhost/shadow_db";
        readonly isProdRequired: true;
    };
    readonly 'database.memcache.hosts': {
        readonly defaultValue: "localhost:11211";
        readonly isProdRequired: true;
    };
    readonly 'database.redis.url': {
        readonly defaultValue: "redis://localhost:6379";
        readonly isProdRequired: true;
    };
    readonly 'database.postgres.lazy-connection': {
        readonly defaultValue: "false";
        readonly validateType: "boolean";
    };
    readonly 'database.postgres.max-connections': {
        readonly validateType: "number";
    };
};
