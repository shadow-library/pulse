export declare function renderPostgresQuery(query: string, params: unknown[]): string;
