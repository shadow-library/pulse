import { OnModuleDestroy, OnModuleInit } from '@shadow-library/app';
import type Redis from 'ioredis';
import type Memcached from 'memcached';
import { type DatabaseModuleOptions, PostgresClient } from './database.types.js';
export type LinkedWithParent<T, U> = T & {
    getParent: () => U;
};
export declare class DatabaseService implements OnModuleInit, OnModuleDestroy {
    private readonly options;
    private readonly logger;
    private postgresClient?;
    private redisClient?;
    private memcacheClient?;
    constructor(options: DatabaseModuleOptions);
    private resolveConnectionUrl;
    private getImportError;
    onModuleInit(): Promise<void>;
    onModuleDestroy(): Promise<void>;
    getPostgresClient(): PostgresClient;
    getRedisClient(): Redis;
    getMemcacheClient(): Memcached;
    isPostgresEnabled(): boolean;
    isRedisEnabled(): boolean;
    isMemcacheEnabled(): boolean;
    private isPostgresError;
    translateError(error: unknown): never;
    attachParent<T extends object, U>(target: T, parent: U): LinkedWithParent<T, U>;
    attachMatchingParent<S extends object, P extends object>(sources: S[], sourceKey: keyof S, parents: P[], parentKey?: keyof P): LinkedWithParent<S, P | null>[];
    attachMatchingParent<S extends object, P extends object>(sources: S[], sourceKey: keyof S, parents: P[], throwErrorIfNotFound: true): LinkedWithParent<S, P>[];
    attachMatchingParent<S extends object, P extends object>(sources: S[], sourceKey: keyof S, parents: P[], parentKey: keyof P, throwErrorIfNotFound: true): LinkedWithParent<S, P>[];
}
