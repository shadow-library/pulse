export declare const HTTP_CORE_CONFIGS: unique symbol;
export declare const LOGGER_NAMESPACE = "@shadow-library/modules/http-core";
export declare const DEFAULT_CONFIGS: {
    readonly 'http-core.csrf.enabled': {
        readonly validateType: "boolean";
        readonly defaultValue: "true";
    };
    readonly 'http-core.helmet.enabled': {
        readonly validateType: "boolean";
    };
    readonly 'http-core.compress.enabled': {
        readonly validateType: "boolean";
    };
    readonly 'http-core.openapi.enabled': {
        readonly validateType: "boolean";
    };
    readonly 'health.host': {
        readonly defaultValue: "localhost";
    };
    readonly 'health.port': {
        readonly validateType: "number";
        readonly defaultValue: "8081";
    };
    readonly 'health.enabled': {
        readonly validateType: "boolean";
        readonly defaultValue: "false" | "true";
    };
};
