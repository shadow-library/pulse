import { EnumType } from '@shadow-library/class-schema';
import { Class } from 'type-fest';
export type SortOrder = 'asc' | 'desc';
export interface IPagination<T> {
    total: number;
    limit: number;
    offset: number;
    items: T[];
}
export interface IPaginationQuery<T extends string = string> {
    limit: number;
    offset: number;
    sortOrder: SortOrder;
    sortBy: T;
}
export declare function Paginated<T>(Item: Class<T>): Class<IPagination<T>>;
export declare function PaginationQuery<T extends string>(SortBy: EnumType<T>, defaults?: Partial<IPaginationQuery<T>>): Class<IPaginationQuery<T>>;
