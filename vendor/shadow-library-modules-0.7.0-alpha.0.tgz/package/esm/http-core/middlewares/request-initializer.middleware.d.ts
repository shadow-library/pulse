import { AsyncHttpMiddleware, HttpRequest, HttpResponse } from '@shadow-library/fastify';
export declare class RequestInitializerMiddleware implements AsyncHttpMiddleware {
    use(request: HttpRequest, response: HttpResponse): Promise<void>;
}
