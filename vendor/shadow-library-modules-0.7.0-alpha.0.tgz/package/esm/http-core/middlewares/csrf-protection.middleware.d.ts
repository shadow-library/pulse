import { AsyncRouteHandler, MiddlewareGenerator } from '@shadow-library/fastify';
import { type HttpCoreModuleOptions } from '../http-core.types.js';
import { CSRFTokenService } from '../services/index.js';
export declare class CsrfProtectionMiddleware implements MiddlewareGenerator {
    private readonly options;
    private readonly csrfTokenService;
    private readonly logger;
    constructor(options: HttpCoreModuleOptions, csrfTokenService: CSRFTokenService);
    private hasCookies;
    generate(): AsyncRouteHandler | undefined;
}
