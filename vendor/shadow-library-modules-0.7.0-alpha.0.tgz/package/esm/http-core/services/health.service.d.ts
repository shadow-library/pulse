import { OnApplicationReady, OnApplicationStop } from '@shadow-library/app';
export declare class HealthService implements OnApplicationReady, OnApplicationStop {
    private readonly logger;
    private isReady;
    private server;
    constructor();
    private createServer;
    onApplicationReady(): void;
    onApplicationStop(): void;
}
