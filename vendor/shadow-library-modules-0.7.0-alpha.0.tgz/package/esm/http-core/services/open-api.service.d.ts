import { FastifyDynamicSwaggerOptions } from '@fastify/swagger';
import { FastifyApiReferenceOptions } from '@scalar/fastify-api-reference';
import { type HttpCoreModuleOptions } from '../http-core.types.js';
export declare class OpenApiService {
    private readonly options;
    private schemaCounter;
    private schemaIdMap;
    constructor(options: HttpCoreModuleOptions);
    private resolveSchemaId;
    private normalizeOpenapiSpec;
    private normalizeParamsOpenapiSpec;
    getFastifySwaggerOptions(): FastifyDynamicSwaggerOptions;
    getScalarOptions(): FastifyApiReferenceOptions;
}
