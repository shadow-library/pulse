import { CookieSerializeOptions } from '@fastify/cookie';
import { HttpRequest } from '@shadow-library/fastify';
import { DurationLike } from 'luxon';
import { type HttpCoreModuleOptions } from '../http-core.types.js';
export interface CSRFOptions {
    disabled?: boolean;
    cookieName: string;
    headerName: string;
    expiresIn: DurationLike;
    refreshLeeway: DurationLike;
    tokenRadix: number;
    tokenLength: number;
}
export interface CSRFCookie {
    name: string;
    value: string;
    options: CookieSerializeOptions;
}
export type CSRFTokenType = 'token' | 'cookie';
interface CSRFTokenValidationResult {
    isValid: boolean;
    reason?: 'missing' | 'invalid' | 'expired' | 'mismatch';
    shouldRefresh?: boolean;
}
export declare class CSRFTokenService {
    private readonly options;
    private readonly logger;
    constructor(options: HttpCoreModuleOptions);
    generateToken(): CSRFCookie;
    validateToken(request: HttpRequest): CSRFTokenValidationResult;
}
export {};
