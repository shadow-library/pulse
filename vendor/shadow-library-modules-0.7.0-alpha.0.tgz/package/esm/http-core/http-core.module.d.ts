import { DynamicModule, OnModuleInit } from '@shadow-library/app';
import { ContextService, type ServerInstance } from '@shadow-library/fastify';
import { PartialDeep } from 'type-fest';
import { type HttpCoreModuleOptions } from './http-core.types.js';
import { OpenApiService } from './services/index.js';
export declare class HttpCoreModule implements OnModuleInit {
    private readonly options;
    private readonly fastify;
    private readonly contextService;
    private readonly openApiService;
    private readonly logger;
    constructor(options: HttpCoreModuleOptions, fastify: ServerInstance, contextService: ContextService, openApiService: OpenApiService);
    private firstDefined;
    onModuleInit(): Promise<void>;
    static forRoot(options?: PartialDeep<HttpCoreModuleOptions>): DynamicModule;
}
