import { type ICacheStore } from './cache.service.js';
import { DatabaseService } from '../database/database.service.js';
export declare class RedisCacheService implements ICacheStore {
    private readonly logger;
    private readonly redis;
    constructor(databaseService: DatabaseService);
    get<T = any>(key: string): Promise<T | null>;
    set<T = any>(key: string, value: T, ttlSeconds?: number): Promise<void>;
    del(key: string): Promise<void>;
    incr(key: string, amount?: number): Promise<number>;
    decr(key: string, amount?: number): Promise<number>;
    publish(channel: string, message: string): Promise<void>;
}
