import { DynamicModule, FactoryProvider, ModuleMetadata } from '@shadow-library/app';
import { Promisable } from 'type-fest';
export interface CacheModuleOptions {
    lruCacheSize?: number;
    lruCacheTTLSeconds?: number;
}
export interface CacheModuleAsyncOptions extends Pick<ModuleMetadata, 'imports'>, Pick<FactoryProvider, 'inject'> {
    useFactory: (...args: unknown[]) => Promisable<CacheModuleOptions>;
}
export declare class CacheModule {
    static forRoot(options: CacheModuleOptions): DynamicModule;
    static forRootAsync(options: CacheModuleAsyncOptions): DynamicModule;
}
