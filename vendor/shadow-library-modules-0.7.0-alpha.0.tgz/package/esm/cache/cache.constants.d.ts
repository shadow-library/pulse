export declare const CACHE_MODULE_OPTIONS: unique symbol;
export declare const LOGGER_NAMESPACE = "@shadow-library/modules/cache";
