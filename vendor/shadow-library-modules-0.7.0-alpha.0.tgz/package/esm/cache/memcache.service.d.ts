import { MaybeNull } from '@shadow-library/common';
import { type ICacheStore } from './cache.service.js';
import { DatabaseService } from '../database/database.service.js';
export declare class MemcacheService implements ICacheStore {
    private readonly logger;
    private readonly memcached?;
    constructor(databaseService: DatabaseService);
    isEnabled(): boolean;
    get<T = any>(key: string): Promise<MaybeNull<T>>;
    set<T = any>(key: string, value: T, ttlSeconds?: number): Promise<void>;
    del(key: string): Promise<void>;
    incr(key: string, amount?: number): Promise<number>;
    decr(key: string, amount?: number): Promise<number>;
}
