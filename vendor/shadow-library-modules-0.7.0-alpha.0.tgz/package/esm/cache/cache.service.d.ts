import { type CacheModuleOptions } from './cache.module.js';
import { MemcacheService } from './memcache.service.js';
import { RedisCacheService } from './redis-cache.service.js';
export interface ICacheStore {
    get<T = any>(key: string): Promise<T | null>;
    set<T = any>(key: string, value: T, ttlSeconds?: number): Promise<void>;
    del(key: string): Promise<void>;
    incr(key: string, amount?: number): Promise<number>;
    decr(key: string, amount?: number): Promise<number>;
}
export declare class CacheService {
    private readonly memcacheService;
    private readonly redisCacheService;
    private readonly logger;
    private readonly lruCache;
    private readonly cacheStore;
    constructor(memcacheService: MemcacheService, redisCacheService: RedisCacheService, options: CacheModuleOptions);
    get<T = any>(key: string): Promise<T | null>;
    set<T = any>(key: string, value: T, ttlSeconds?: number): Promise<void>;
    del(key: string): Promise<void>;
}
