/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
/**
 * Declaring the constants
 */
export declare const NAMESPACE = "@shadow-library/auth";
