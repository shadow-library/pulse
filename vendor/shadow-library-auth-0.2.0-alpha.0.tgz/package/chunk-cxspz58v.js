// @bun
import {
  AuthErrorCode,
  DiscoveryClient,
  NAMESPACE,
  RemoteJwks,
  verifyJwt
} from "./chunk-qyzf2w7p.js";

// src/rp/pkce.ts
var encoder = new TextEncoder;
function randomUrlSafeString(bytes = 32) {
  const buffer = new Uint8Array(bytes);
  crypto.getRandomValues(buffer);
  return Buffer.from(buffer).toString("base64url");
}
async function createPkcePair() {
  const verifier = randomUrlSafeString(32);
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(verifier));
  return { verifier, challenge: Buffer.from(digest).toString("base64url") };
}

// src/rp/relying-party.ts
import { Logger, throwError } from "@shadow-library/common";
var DEFAULT_SCOPES = ["openid"];
var DEFAULT_CLOCK_SKEW_SECONDS = 60;
var DEFAULT_JWKS_TTL_SECONDS = 300;

class RelyingParty {
  config;
  logger = Logger.getLogger(NAMESPACE, RelyingParty.name);
  issuer;
  transport;
  discovery;
  jwks;
  constructor(config) {
    this.config = config;
    if (!config.issuer || !URL.canParse(config.issuer))
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "issuer must be a valid url" });
    if (!config.client?.id)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "client id is required" });
    if (!config.redirectUri || !URL.canParse(config.redirectUri))
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "redirect uri must be a valid url" });
    this.issuer = config.issuer.replace(/\/+$/, "");
    this.transport = config.fetch ?? ((url, init) => fetch(url, init));
    this.discovery = new DiscoveryClient(this.issuer, this.transport);
    this.jwks = new RemoteJwks({ discovery: this.discovery, fetchFn: this.transport, ttlSeconds: config.cache?.jwksTtlSeconds ?? DEFAULT_JWKS_TTL_SECONDS });
  }
  async createAuthorizationUrl(options = {}) {
    const document = await this.discovery.get();
    const pkce = await createPkcePair();
    const state = options.state ?? randomUrlSafeString(16);
    const nonce = options.nonce ?? randomUrlSafeString(16);
    const url = new URL(document.authorization_endpoint);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", this.config.client.id);
    url.searchParams.set("redirect_uri", this.config.redirectUri);
    url.searchParams.set("scope", (options.scopes ?? this.config.scopes ?? DEFAULT_SCOPES).join(" "));
    url.searchParams.set("state", state);
    url.searchParams.set("nonce", nonce);
    url.searchParams.set("code_challenge", pkce.challenge);
    url.searchParams.set("code_challenge_method", "S256");
    if (options.resource)
      url.searchParams.set("resource", options.resource);
    this.logger.debug("authorization url created", { state, nonce, scopes: options.scopes ?? this.config.scopes ?? DEFAULT_SCOPES });
    return { url: url.toString(), state, nonce, codeVerifier: pkce.verifier };
  }
  async exchangeCode(input) {
    const body = { grant_type: "authorization_code", code: input.code, redirect_uri: this.config.redirectUri, code_verifier: input.codeVerifier };
    const tokens = await this.requestTokens(body);
    if (tokens.idToken)
      tokens.idTokenClaims = await this.validateIdToken(tokens.idToken, input.nonce);
    this.logger.info("authorization code exchanged", { hasIdToken: Boolean(tokens.idToken) });
    this.logger.debug("id token claims resolved", { sub: tokens.idTokenClaims?.sub });
    return tokens;
  }
  async refresh(refreshToken) {
    return this.requestTokens({ grant_type: "refresh_token", refresh_token: refreshToken });
  }
  async requestTokens(body) {
    const document = await this.discovery.get();
    const headers = { "content-type": "application/json" };
    if (this.config.client.secret)
      headers.authorization = `Basic ${Buffer.from(`${this.config.client.id}:${this.config.client.secret}`).toString("base64")}`;
    else
      body.client_id = this.config.client.id;
    this.logger.debug("requesting tokens", { url: document.token_endpoint, grantType: body.grant_type });
    const response = await this.transport(document.token_endpoint, { method: "POST", headers, body: JSON.stringify(body) }).catch((error) => throwError(this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: `token request failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: `token endpoint returned http ${response.status}` }));
    const payload = await response.json();
    if (!payload.access_token || typeof payload.expires_in !== "number")
      throw this.logged(AuthErrorCode.EXCHANGE_FAILED.create({ reason: "malformed token endpoint response" }));
    return {
      accessToken: payload.access_token,
      tokenType: payload.token_type ?? "Bearer",
      expiresIn: payload.expires_in,
      scope: payload.scope,
      idToken: payload.id_token,
      refreshToken: payload.refresh_token
    };
  }
  validateIdToken(idToken, nonce) {
    const expectations = { issuer: this.issuer, audience: this.config.client.id, clockSkewSeconds: this.config.clockSkewSeconds ?? DEFAULT_CLOCK_SKEW_SECONDS, nonce };
    return verifyJwt(idToken, (kid) => this.jwks.getKey(kid), expectations);
  }
  logged(error) {
    this.logger.error(error.message);
    return error;
  }
}

export { randomUrlSafeString, createPkcePair, RelyingParty };
