import { AuthClientCredential, FetchLike, ServiceTokenOptions } from '../interfaces';
import { DiscoveryClient } from './discovery';
/**
 * Defining types
 */
export interface ServiceTokenManagerOptions {
    discovery: DiscoveryClient;
    fetchFn: FetchLike;
    client?: AuthClientCredential;
    refreshSkewSeconds?: number;
}
export declare class ServiceTokenManager {
    private readonly options;
    private readonly logger;
    private readonly cache;
    private readonly inflight;
    constructor(options: ServiceTokenManagerOptions);
    getToken(options?: ServiceTokenOptions): Promise<string>;
    invalidate(options?: ServiceTokenOptions): void;
    private cacheKey;
    private request;
    /** Read fresh on every request — the kubelet rotates the projected token in place */
    private readAssertion;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
