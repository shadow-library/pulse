import { CheckInput, CheckOptions, FetchLike } from '../interfaces';
/**
 * Defining types
 */
export interface PdpClientOptions {
    issuer: string;
    fetchFn: FetchLike;
    /** Supplies the SDK's own M2M bearer for PDP calls; a failed acquisition falls back to an unauthenticated call */
    getToken?: () => Promise<string>;
    ttlSeconds?: number;
    maxEntries?: number;
}
export declare class PdpClient {
    private readonly options;
    private readonly logger;
    private readonly cache;
    private readonly versions;
    constructor(options: PdpClientOptions);
    check(input: CheckInput, options?: CheckOptions): Promise<boolean>;
    checkAll(inputs: CheckInput[], options?: CheckOptions): Promise<boolean[]>;
    private request;
    private observeVersion;
    private store;
}
