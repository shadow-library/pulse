import { AuthClientConfig, AuthPrincipal, CheckInput, CheckOptions, IntrospectionResult, RoleCatalogManifest, RoleCatalogSyncResult, ServiceAccessRule, ServiceTokenOptions } from '../interfaces';
/**
 * The consumer-facing auth client: offline token verification, PDP checks, M2M tokens, role
 * catalog sync, and admin-managed service-access rules. Designed as an injectable class —
 * `AuthModule.forRoot()` registers it under its own class token so application services take it
 * as an ordinary constructor dependency.
 */
export declare class AuthClient {
    private readonly config;
    private readonly logger;
    private readonly issuer;
    private readonly transport;
    private readonly clockSkewSeconds;
    private readonly jwks;
    private readonly tokens;
    private readonly pdp;
    private readonly discovery;
    private readonly services;
    private serviceAccess;
    constructor(config: AuthClientConfig);
    /** Verifies a bearer token offline against the issuer's JWKS and returns the resolved principal */
    verify(token: string): Promise<AuthPrincipal>;
    /** Asks the PDP whether the principal may perform the action; deny-by-default on any failure */
    check(input: CheckInput, options?: CheckOptions): Promise<boolean>;
    checkAll(inputs: CheckInput[], options?: CheckOptions): Promise<boolean[]>;
    /** Returns a cached client-credentials token for calling another service */
    getServiceToken(options?: ServiceTokenOptions): Promise<string>;
    /** `fetch` with the service token injected and a single automatic retry on a stale-token 401 */
    fetch(url: string, init?: RequestInit, options?: ServiceTokenOptions): Promise<Response>;
    /** Resolves a service name to its base URL (in-cluster svc DNS by default, env-overridable) */
    resolveService(service: string): string;
    /** `fetch` against a named service: svc-DNS resolution plus a service token addressed to it */
    fetchService(service: string, path: string, init?: RequestInit, options?: ServiceTokenOptions): Promise<Response>;
    /** Declaratively replaces this application's role catalog in identity; requires service-account credentials */
    syncRoles(manifest: RoleCatalogManifest): Promise<RoleCatalogSyncResult>;
    /**
     * Loads the admin-configured service-access rules for this application from identity. Called by
     * `AuthModule` at startup; until it succeeds, every service-to-service caller is denied
     * (deny-by-default), so a failure here should abort the boot rather than be swallowed.
     */
    loadServiceAccess(): Promise<ServiceAccessRule[]>;
    /** Whether an M2M caller may invoke the given route, per the rules loaded from identity */
    isServiceCallerAllowed(callerClientId: string, method: string, path: string): boolean;
    /** Explicit fallback for opaque tokens; MUST NOT be used for routine verification */
    introspect(token: string): Promise<IntrospectionResult>;
    private identityToken;
    private matchesMethod;
    private matchesPath;
    private expectations;
    private toPrincipal;
    private withBearer;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
