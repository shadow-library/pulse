/**
 * Defining types
 */
export interface ServiceDiscoveryOptions {
    /** Appended to the service name when building the default in-cluster URL, e.g. `.prod.svc.cluster.local` */
    domainSuffix?: string;
    /** Scheme of the default in-cluster URL. Defaults to `http` (in-cluster traffic behind the mesh) */
    scheme?: 'http' | 'https';
    /** Environment source override, primarily for tests. Defaults to `process.env` */
    env?: Record<string, string | undefined>;
}
export declare class ServiceDiscovery {
    private readonly options;
    private readonly logger;
    private readonly env;
    constructor(options?: ServiceDiscoveryOptions);
    /** Resolves a service name to its base URL: env override first, in-cluster svc DNS otherwise */
    resolve(service: string): string;
    /** Builds a full URL for a path on the named service */
    url(service: string, path: string): string;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
