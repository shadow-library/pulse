import { FetchLike } from '../interfaces';
import { DiscoveryClient } from './discovery';
/**
 * Defining types
 */
export interface RemoteJwksOptions {
    discovery: DiscoveryClient;
    fetchFn: FetchLike;
    ttlSeconds: number;
}
export declare class RemoteJwks {
    private readonly options;
    private readonly logger;
    private keys;
    private fetchedAt;
    private lastMissAt;
    private inflight;
    constructor(options: RemoteJwksOptions);
    getKey(kid: string): Promise<CryptoKey>;
    private refresh;
    private load;
    /** Records the failure at error level before it propagates, keeping guard throws single-line */
    private logged;
}
