/**
 * Importing npm packages
 */
import { ErrorCode } from '@shadow-library/common';
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
/**
 * Declaring the constants
 *
 * The SDK error catalog: keys create and throw `AppError`s directly. Call-site context travels in
 * the `data` payload (e.g. `{ reason }`), keeping the catalog message stable while structured
 * detail flows into logs. Transient transport failures use `unavailable` (retryable, 503); broken
 * configuration uses `internal` (a defect — masked outside logs).
 */
export declare class AuthErrorCode extends ErrorCode {
    /*!
     * Configuration Errors
     */
    /** The auth client configuration is invalid */
    static readonly CONFIG_INVALID: AuthErrorCode;
    /*!
     * Token Verification Errors
     */
    /** The token algorithm is not in the allow-list */
    static readonly ALG_REJECTED: AuthErrorCode;
    /** The token is not addressed to this audience */
    static readonly AUDIENCE_MISMATCH: AuthErrorCode;
    /** The token was issued by an untrusted issuer */
    static readonly ISSUER_MISMATCH: AuthErrorCode;
    /** No published JWKS key matches the token's kid */
    static readonly KEY_UNKNOWN: AuthErrorCode;
    /** The token nonce does not match the expected nonce */
    static readonly NONCE_MISMATCH: AuthErrorCode;
    /** The token has expired */
    static readonly TOKEN_EXPIRED: AuthErrorCode;
    /** The token is malformed or its signature does not verify */
    static readonly TOKEN_INVALID: AuthErrorCode;
    /*!
     * OIDC Relying-Party Errors
     */
    /** OIDC discovery failed or answered with an inconsistent document */
    static readonly DISCOVERY_FAILED: AuthErrorCode;
    /** The authorization-code exchange failed */
    static readonly EXCHANGE_FAILED: AuthErrorCode;
    /** The token introspection request failed */
    static readonly INTROSPECTION_FAILED: AuthErrorCode;
    /*!
     * Machine-to-Machine Errors
     */
    /** The policy decision point is unreachable or answered malformed */
    static readonly PDP_UNAVAILABLE: AuthErrorCode;
    /** The role-catalog sync was rejected or unreachable */
    static readonly ROLE_SYNC_FAILED: AuthErrorCode;
    /** The service-access rules could not be loaded at startup */
    static readonly SERVICE_ACCESS_FAILED: AuthErrorCode;
    /** The service name is invalid or cannot be resolved */
    static readonly SERVICE_UNKNOWN: AuthErrorCode;
    /** The client-credentials token request failed */
    static readonly TOKEN_REQUEST_FAILED: AuthErrorCode;
}
