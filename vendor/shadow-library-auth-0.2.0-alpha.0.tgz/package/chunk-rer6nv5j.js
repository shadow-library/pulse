// @bun
import {
  AuthErrorCode,
  DiscoveryClient,
  NAMESPACE,
  RemoteJwks,
  verifyJwt
} from "./chunk-qyzf2w7p.js";

// src/lib/service-discovery.ts
import { Logger } from "@shadow-library/common";
var SERVICE_NAME_PATTERN = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/;

class ServiceDiscovery {
  options;
  logger = Logger.getLogger(NAMESPACE, ServiceDiscovery.name);
  env;
  constructor(options = {}) {
    this.options = options;
    this.env = options.env ?? process.env;
  }
  resolve(service) {
    if (!SERVICE_NAME_PATTERN.test(service))
      throw this.logged(AuthErrorCode.SERVICE_UNKNOWN.create({ reason: `'${service}' is not a valid service name` }));
    const override = this.env[`SERVICE_URL_${service.toUpperCase().replaceAll("-", "_")}`];
    if (override) {
      if (!URL.canParse(override))
        throw this.logged(AuthErrorCode.SERVICE_UNKNOWN.create({ reason: `service url override for '${service}' is not a valid url` }));
      const url2 = override.replace(/\/+$/, "");
      this.logger.debug("service url resolved from env override", { service, url: url2 });
      return url2;
    }
    const scheme = this.options.scheme ?? this.env["SERVICE_DISCOVERY_SCHEME"] ?? "http";
    const suffix = this.options.domainSuffix ?? this.env["SERVICE_DISCOVERY_SUFFIX"] ?? "";
    const url = `${scheme}://${service}${suffix}`;
    this.logger.debug("service url resolved", { service, url });
    return url;
  }
  url(service, path) {
    const base = this.resolve(service);
    return path.startsWith("/") ? `${base}${path}` : `${base}/${path}`;
  }
  logged(error) {
    this.logger.error(error.message);
    return error;
  }
}

// src/lib/auth-client.ts
import { Logger as Logger4, throwError as throwError2 } from "@shadow-library/common";

// src/lib/pdp-client.ts
import { Logger as Logger2 } from "@shadow-library/common";
var DEFAULT_TTL_SECONDS = 900;
var HIGH_RISK_TTL_SECONDS = 60;
var DEFAULT_MAX_ENTRIES = 1000;

class PdpClient {
  options;
  logger = Logger2.getLogger(NAMESPACE, PdpClient.name);
  cache = new Map;
  versions = new Map;
  constructor(options) {
    this.options = options;
  }
  async check(input, options = {}) {
    const organisationId = input.organisationId ?? input.principal.org;
    if (!organisationId)
      return false;
    const principalKey = `${input.principal.kind}:${input.principal.sub}`;
    const key = `${principalKey}:${organisationId}:${input.action}`;
    const minVersion = this.versions.get(principalKey) ?? 0;
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now() && cached.authzVersion >= minVersion) {
      this.cache.delete(key);
      this.cache.set(key, cached);
      return cached.permitted;
    }
    try {
      return await this.request(principalKey, key, organisationId, input, options);
    } catch (error) {
      this.logger.warn("pdp check failed; applying fallback decision", { action: input.action, failOpen: options.failOpen ?? false, reason: error.message });
      return options.failOpen ?? false;
    }
  }
  checkAll(inputs, options = {}) {
    return Promise.all(inputs.map((input) => this.check(input, options)));
  }
  async request(principalKey, key, organisationId, input, options) {
    const headers = { "content-type": "application/json" };
    const token = await this.options.getToken?.().catch((error) => {
      this.logger.warn("pdp token acquisition failed; calling unauthenticated", { reason: error.message });
      return null;
    });
    if (token)
      headers.authorization = `Bearer ${token}`;
    const body = JSON.stringify({
      principalType: input.principal.kind === "service" ? "SERVICE_ACCOUNT" : "USER",
      principalId: input.principal.sub,
      organisationId,
      action: input.action
    });
    const response = await this.options.fetchFn(`${this.options.issuer}/api/v1/authz/check`, { method: "POST", headers, body });
    if (!response.ok)
      throw AuthErrorCode.PDP_UNAVAILABLE.create({ reason: `pdp returned http ${response.status}` });
    const result = await response.json();
    if (result.decision !== "PERMIT" && result.decision !== "DENY")
      throw AuthErrorCode.PDP_UNAVAILABLE.create({ reason: "malformed pdp response" });
    const authzVersion = result.authzVersion ?? 0;
    this.observeVersion(principalKey, authzVersion);
    const permitted = result.decision === "PERMIT";
    this.logger.debug("pdp decision", { principal: principalKey, organisationId, action: input.action, decision: result.decision });
    const baseTtl = this.options.ttlSeconds ?? DEFAULT_TTL_SECONDS;
    const ttlSeconds = options.highRisk ? Math.min(HIGH_RISK_TTL_SECONDS, baseTtl) : baseTtl;
    this.store(key, { permitted, authzVersion, expiresAt: Date.now() + ttlSeconds * 1000 });
    return permitted;
  }
  observeVersion(principalKey, version) {
    const known = this.versions.get(principalKey) ?? 0;
    if (version <= known)
      return;
    this.logger.debug("authz version bump observed; invalidating cached decisions", { principal: principalKey, version });
    this.versions.set(principalKey, version);
    for (const [key, entry] of this.cache) {
      if (key.startsWith(`${principalKey}:`) && entry.authzVersion < version)
        this.cache.delete(key);
    }
  }
  store(key, entry) {
    this.cache.delete(key);
    this.cache.set(key, entry);
    if (this.cache.size <= (this.options.maxEntries ?? DEFAULT_MAX_ENTRIES))
      return;
    const oldest = this.cache.keys().next().value;
    if (oldest)
      this.cache.delete(oldest);
  }
}

// src/lib/token-manager.ts
import { readFile } from "fs/promises";
import { Logger as Logger3, throwError } from "@shadow-library/common";
var DEFAULT_REFRESH_SKEW_SECONDS = 60;
var JWT_BEARER_ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

class ServiceTokenManager {
  options;
  logger = Logger3.getLogger(NAMESPACE, ServiceTokenManager.name);
  cache = new Map;
  inflight = new Map;
  constructor(options) {
    this.options = options;
  }
  async getToken(options = {}) {
    const client = this.options.client;
    if (!client)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "service tokens require client credentials" });
    const key = this.cacheKey(options);
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now())
      return cached.token;
    const pending = this.inflight.get(key);
    if (pending)
      return pending;
    const request = this.request(key, options, client).finally(() => this.inflight.delete(key));
    this.inflight.set(key, request);
    return request;
  }
  invalidate(options = {}) {
    this.logger.debug("service token invalidated", { resource: options.resource, scopes: options.scopes });
    this.cache.delete(this.cacheKey(options));
  }
  cacheKey(options) {
    const scopes = [...options.scopes ?? []].sort();
    return `${options.resource ?? ""}|${scopes.join(" ")}`;
  }
  async request(key, options, client) {
    const document = await this.options.discovery.get();
    const scopes = [...options.scopes ?? []].sort();
    const headers = { "content-type": "application/json" };
    const body = { grant_type: "client_credentials" };
    if (client.assertionPath) {
      body.client_id = client.id;
      body.client_assertion_type = JWT_BEARER_ASSERTION_TYPE;
      body.client_assertion = await this.readAssertion(client.assertionPath);
    } else if (client.secret) {
      headers.authorization = `Basic ${Buffer.from(`${client.id}:${client.secret}`).toString("base64")}`;
    } else {
      body.client_id = client.id;
    }
    if (scopes.length > 0)
      body.scope = scopes.join(" ");
    if (options.resource)
      body.resource = options.resource;
    this.logger.debug("requesting service token", { url: document.token_endpoint, body });
    const response = await this.options.fetchFn(document.token_endpoint, { method: "POST", headers, body: JSON.stringify(body) }).catch((error) => throwError(this.logged(AuthErrorCode.TOKEN_REQUEST_FAILED.create({ reason: `token request failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.TOKEN_REQUEST_FAILED.create({ reason: `token endpoint returned http ${response.status}` }));
    const payload = await response.json();
    if (!payload.access_token || typeof payload.expires_in !== "number")
      throw this.logged(AuthErrorCode.TOKEN_REQUEST_FAILED.create({ reason: "malformed token endpoint response" }));
    this.logger.info("service token minted", { clientId: client.id, resource: options.resource, scopes, expiresIn: payload.expires_in });
    const refreshSkew = this.options.refreshSkewSeconds ?? DEFAULT_REFRESH_SKEW_SECONDS;
    this.cache.set(key, { token: payload.access_token, expiresAt: Date.now() + (payload.expires_in - refreshSkew) * 1000 });
    return payload.access_token;
  }
  async readAssertion(path) {
    const assertion = await readFile(path, "utf8").catch((error) => throwError(this.logged(AuthErrorCode.TOKEN_REQUEST_FAILED.create({ reason: `could not read service-account token at '${path}': ${error.message}` }))));
    const trimmed = assertion.trim();
    if (!trimmed)
      throw this.logged(AuthErrorCode.TOKEN_REQUEST_FAILED.create({ reason: `service-account token at '${path}' is empty` }));
    return trimmed;
  }
  logged(error) {
    this.logger.error(error.message);
    return error;
  }
}

// src/lib/auth-client.ts
var DEFAULT_CLOCK_SKEW_SECONDS = 60;
var DEFAULT_JWKS_TTL_SECONDS = 43200;
var DEFAULT_DECISION_TTL_SECONDS = 900;
var DEFAULT_IDENTITY_RESOURCE = "shadow-identity";
var PDP_SCOPE = "authz:check";
var ROLE_SYNC_SCOPE = "authz:roles:sync";

class AuthClient {
  config;
  logger = Logger4.getLogger(NAMESPACE, AuthClient.name);
  issuer;
  transport;
  clockSkewSeconds;
  jwks;
  tokens;
  pdp;
  discovery;
  services;
  serviceAccess = null;
  constructor(config) {
    this.config = config;
    if (!config.issuer || !URL.canParse(config.issuer))
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "issuer must be a valid url" });
    if (!config.audience)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "audience is required" });
    if (config.client && !config.client.id)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "client credentials require an id" });
    if ((config.clockSkewSeconds ?? 0) < 0)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "clock skew cannot be negative" });
    this.issuer = config.issuer.replace(/\/+$/, "");
    this.transport = config.fetch ?? ((url, init) => fetch(url, init));
    this.clockSkewSeconds = config.clockSkewSeconds ?? DEFAULT_CLOCK_SKEW_SECONDS;
    this.discovery = new DiscoveryClient(this.issuer, this.transport);
    this.services = new ServiceDiscovery;
    this.jwks = new RemoteJwks({ discovery: this.discovery, fetchFn: this.transport, ttlSeconds: config.cache?.jwksTtlSeconds ?? DEFAULT_JWKS_TTL_SECONDS });
    this.tokens = new ServiceTokenManager({ discovery: this.discovery, fetchFn: this.transport, client: config.client });
    this.pdp = new PdpClient({
      issuer: this.issuer,
      fetchFn: this.transport,
      ttlSeconds: config.cache?.decisionTtlSeconds ?? DEFAULT_DECISION_TTL_SECONDS,
      getToken: config.client ? () => this.identityToken(PDP_SCOPE) : undefined
    });
    this.logger.info("auth client initialised", { issuer: this.issuer, audience: config.audience, hasClientCredentials: Boolean(config.client) });
  }
  async verify(token) {
    if (!token)
      throw AuthErrorCode.TOKEN_INVALID.create({ reason: "no token provided" });
    const payload = await verifyJwt(token, (kid) => this.jwks.getKey(kid), this.expectations());
    const principal = this.toPrincipal(payload);
    this.logger.debug("token verified", { sub: principal.sub, kind: principal.kind, scopes: principal.scopes });
    return principal;
  }
  check(input, options) {
    return this.pdp.check(input, options);
  }
  checkAll(inputs, options) {
    return this.pdp.checkAll(inputs, options);
  }
  getServiceToken(options) {
    return this.tokens.getToken(options);
  }
  async fetch(url, init = {}, options = {}) {
    this.logger.debug("calling service endpoint", { url, method: init.method ?? "GET", resource: options.resource });
    const token = await this.tokens.getToken(options);
    const response = await this.transport(url, this.withBearer(init, token));
    if (response.status !== 401)
      return response;
    this.logger.warn("service call rejected with 401; retrying with a fresh token", { url });
    this.tokens.invalidate(options);
    const fresh = await this.tokens.getToken(options);
    return this.transport(url, this.withBearer(init, fresh));
  }
  resolveService(service) {
    return this.services.resolve(service);
  }
  fetchService(service, path, init = {}, options = {}) {
    return this.fetch(this.services.url(service, path), init, { ...options, resource: options.resource ?? service });
  }
  async syncRoles(manifest) {
    if (!this.config.client)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "role sync requires service-account client credentials" });
    const token = await this.identityToken(ROLE_SYNC_SCOPE);
    const headers = { "content-type": "application/json", authorization: `Bearer ${token}` };
    const response = await this.transport(`${this.issuer}/api/v1/authz/catalog`, { method: "PUT", headers, body: JSON.stringify(manifest) }).catch((error) => throwError2(this.logged(AuthErrorCode.ROLE_SYNC_FAILED.create({ reason: `role sync failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.ROLE_SYNC_FAILED.create({ reason: `role sync endpoint returned http ${response.status}` }));
    const result = await response.json();
    this.logger.info("role catalog synced", { permissions: manifest.permissions.length, roles: manifest.roles.length });
    return result;
  }
  async loadServiceAccess() {
    if (!this.config.client)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "service access rules require service-account client credentials" });
    const token = await this.identityToken(PDP_SCOPE);
    const response = await this.transport(`${this.issuer}/api/v1/authz/service-access`, { headers: { authorization: `Bearer ${token}` } }).catch((error) => throwError2(this.logged(AuthErrorCode.SERVICE_ACCESS_FAILED.create({ reason: `service access fetch failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.SERVICE_ACCESS_FAILED.create({ reason: `service access endpoint returned http ${response.status}` }));
    const body = await response.json();
    this.serviceAccess = body.rules ?? [];
    this.logger.info("service access rules loaded", { rules: this.serviceAccess.length });
    return this.serviceAccess;
  }
  isServiceCallerAllowed(callerClientId, method, path) {
    if (!this.serviceAccess)
      return false;
    return this.serviceAccess.some((rule) => rule.callerClientId === callerClientId && this.matchesMethod(rule.method, method) && this.matchesPath(rule.path, path));
  }
  async introspect(token) {
    const client = this.config.client;
    if (!client?.secret)
      throw AuthErrorCode.CONFIG_INVALID.create({ reason: "introspection requires confidential client credentials" });
    const document = await this.discovery.get();
    const endpoint = document.introspection_endpoint ?? `${this.issuer}/oauth2/introspect`;
    const headers = { "content-type": "application/json", authorization: `Basic ${Buffer.from(`${client.id}:${client.secret}`).toString("base64")}` };
    const response = await this.transport(endpoint, { method: "POST", headers, body: JSON.stringify({ token }) }).catch((error) => throwError2(this.logged(AuthErrorCode.INTROSPECTION_FAILED.create({ reason: `introspection failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.INTROSPECTION_FAILED.create({ reason: `introspection endpoint returned http ${response.status}` }));
    const result = await response.json();
    return { active: result.active === true, sub: result.sub, scope: result.scope, aud: result.aud, exp: result.exp, clientId: result.client_id, tokenType: result.token_type };
  }
  identityToken(scope) {
    return this.tokens.getToken({ resource: this.config.identityResource ?? DEFAULT_IDENTITY_RESOURCE, scopes: [scope] });
  }
  matchesMethod(pattern, method) {
    return pattern === "*" || pattern.toUpperCase() === method.toUpperCase();
  }
  matchesPath(pattern, path) {
    if (pattern.endsWith("*"))
      return path.startsWith(pattern.slice(0, -1));
    return pattern === path;
  }
  expectations() {
    return { issuer: this.issuer, audience: this.config.audience, clockSkewSeconds: this.clockSkewSeconds };
  }
  toPrincipal(payload) {
    if (typeof payload.sub !== "string" || !payload.sub)
      throw AuthErrorCode.TOKEN_INVALID.create({ reason: "missing sub claim" });
    return {
      kind: payload.token_type === "service" ? "service" : "user",
      sub: payload.sub,
      scopes: typeof payload.scope === "string" ? payload.scope.split(" ").filter(Boolean) : [],
      clientId: typeof payload.client_id === "string" ? payload.client_id : undefined,
      org: typeof payload.org === "string" ? payload.org : undefined,
      sid: typeof payload.sid === "string" ? payload.sid : undefined,
      aal: typeof payload.aal === "string" ? payload.aal : undefined,
      claims: payload
    };
  }
  withBearer(init, token) {
    const headers = new Headers(init.headers);
    headers.set("authorization", `Bearer ${token}`);
    return { ...init, headers };
  }
  logged(error) {
    this.logger.error(error.message);
    return error;
  }
}

export { ServiceDiscovery, AuthClient };
