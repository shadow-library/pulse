/**
 * Importing user defined packages
 */
import { type AuthClientConfig } from '../interfaces';
/**
 * Defining types
 */
declare module '@shadow-library/common' {
    interface ConfigRecords {
        /** Auth SDK configs (consumed by `AuthModule.forRoot` / `RelyingPartyModule.forRoot`) */
        'auth.issuer': string;
        'auth.audience': string;
        'auth.client.id': string;
        'auth.client.secret': string;
        'auth.client.assertion-path': string;
    }
}
/** Everything is optional: whatever is not passed in code is resolved from the environment */
export type AuthModuleOptions = Partial<AuthClientConfig>;
/** Fills any option not supplied in code from the corresponding `AUTH_*` environment config */
export declare function resolveAuthClientConfig(options?: AuthModuleOptions): AuthClientConfig;
