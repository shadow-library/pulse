/**
 * Importing npm packages
 */
import { DynamicModule } from '@shadow-library/app';
/**
 * Importing user defined packages
 */
import './config';
import { type RelyingPartyConfig } from '../rp/relying-party';
/**
 * Defining types
 */
/** The issuer falls back to the `AUTH_ISSUER` environment config when not passed in code */
export type RelyingPartyModuleOptions = Omit<RelyingPartyConfig, 'issuer'> & {
    issuer?: string;
};
/**
 * Declaring the constants
 */
export declare class RelyingPartyModule {
    static forRoot(options: RelyingPartyModuleOptions): DynamicModule;
}
