/**
 * Defining types
 */
export interface AuthRouteMetadata {
    authenticated: true;
    scopes?: string[];
    permission?: string;
    failOpen?: boolean;
    highRisk?: boolean;
}
export interface RequirePermissionOptions {
    /** Permits the action when the PDP is unreachable — explicit opt-in for availability-critical read paths */
    failOpen?: boolean;
    /** Caches this route's PDP decision for ~60 s instead of the default 15 min — for sensitive operations that need fast revocation */
    highRisk?: boolean;
}
type AuthDecorator = ClassDecorator & MethodDecorator;
/** Requires a valid bearer token; the resolved principal is exposed via `context.getAuthPrincipal()` */
export declare const Authenticated: () => AuthDecorator;
/** Requires a valid bearer token carrying every listed scope */
export declare const RequireScope: (...scopes: string[]) => AuthDecorator;
/** Requires a PDP PERMIT for the action, checked in the principal's organisation (implies `@Authenticated`) */
export declare const RequirePermission: (permission: string, options?: RequirePermissionOptions) => AuthDecorator;
export {};
