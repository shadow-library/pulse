/**
 * Importing npm packages
 */
import { type HandlerMetadata } from '@shadow-library/app';
import { ContextService } from '@shadow-library/fastify';
import { AuthClient } from '../lib/auth-client';
/**
 * Defining types
 */
export interface GuardedRequest {
    headers: Record<string, string | string[] | undefined>;
}
export type AuthGuardHandler = (request: GuardedRequest) => Promise<void>;
/**
 * Declaring the constants
 *
 * The guard only attaches to routes that carry auth metadata, so unguarded routes pay no cost.
 * Every failure is deliberately mapped to the same generic 401/403 pair — the response never
 * explains which check failed, only the audit-friendly error code differs. M2M callers are
 * deny-by-default: a service token passes only when an admin-configured service-access rule
 * (loaded from identity at startup) covers this route for that caller.
 */
export declare class AuthGuard {
    private readonly client;
    private readonly context;
    private readonly logger;
    constructor(client: AuthClient, context: ContextService);
    /** The router caches generated handlers by metadata alone; namespacing avoids colliding with other generating middlewares on the same route */
    cacheKey(metadata: HandlerMetadata): string;
    generate(metadata: HandlerMetadata): AuthGuardHandler | undefined;
    private authenticate;
    private authorize;
    private checkPermission;
    /** Warn-level trail for rejected credentials; the response stays a generic 401 */
    private unauthenticated;
    /** Warn-level trail for denied requests; the response stays a generic 403 */
    private denied;
}
