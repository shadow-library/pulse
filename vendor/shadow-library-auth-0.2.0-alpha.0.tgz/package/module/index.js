// @bun
import {
  AuthClient
} from "../chunk-rer6nv5j.js";
import {
  RelyingParty
} from "../chunk-cxspz58v.js";
import {
  NAMESPACE
} from "../chunk-qyzf2w7p.js";
import {
  __legacyDecorateClassTS,
  __legacyDecorateParamTS,
  __legacyMetadataTS
} from "../chunk-561v8w9j.js";

// src/module/auth-guard.ts
import { Logger, throwError } from "@shadow-library/common";
import { ContextService, Middleware } from "@shadow-library/fastify";

// src/module/constants.ts
var AUTH_ROUTE_METADATA = "shadowAuth";

// src/module/errors.ts
import { ServerErrorCode } from "@shadow-library/fastify";

class AuthGuardErrorCode extends ServerErrorCode {
  static IAM_001 = AuthGuardErrorCode.unauthenticated("IAM_001", "Authentication required");
  static IAM_002 = AuthGuardErrorCode.forbidden("IAM_002", "Permission denied");
}

// src/module/context.ts
var AUTH_PRINCIPAL = Symbol("shadow-library:auth-principal");
function extendContextWithAuth(context) {
  context.extend({
    getAuthPrincipal() {
      const principal = this.get(AUTH_PRINCIPAL);
      if (!principal)
        throw AuthGuardErrorCode.IAM_001.create();
      return principal;
    },
    getAuthPrincipalOrNull() {
      return this.get(AUTH_PRINCIPAL);
    }
  });
}

// src/module/auth-guard.ts
class AuthGuard {
  client;
  context;
  logger = Logger.getLogger(NAMESPACE, AuthGuard.name);
  constructor(client, context) {
    this.client = client;
    this.context = context;
  }
  cacheKey(metadata) {
    return `shadow-auth:${String(metadata.method)}:${String(metadata.path)}`;
  }
  generate(metadata) {
    const auth = metadata[AUTH_ROUTE_METADATA];
    if (!auth?.authenticated)
      return;
    const method = String(metadata.method ?? "*");
    const path = String(metadata.path ?? "/");
    return async (request) => {
      const principal = await this.authenticate(request);
      this.authorize(principal, auth, method, path);
      if (auth.permission)
        await this.checkPermission(principal, auth);
      this.context.set(AUTH_PRINCIPAL, principal);
      this.logger.debug("request authenticated", { sub: principal.sub, kind: principal.kind, method, path });
    };
  }
  async authenticate(request) {
    const header = request.headers.authorization;
    const token = typeof header === "string" && header.startsWith("Bearer ") ? header.slice(7) : undefined;
    if (!token)
      throw AuthGuardErrorCode.IAM_001.create();
    return this.client.verify(token).catch((error) => throwError(this.unauthenticated(error)));
  }
  authorize(principal, auth, method, path) {
    if (principal.kind === "service" && (!principal.clientId || !this.client.isServiceCallerAllowed(principal.clientId, method, path))) {
      throw this.denied("service caller not allowed for this route", { clientId: principal.clientId, method, path });
    }
    if (auth.scopes?.some((scope) => !principal.scopes.includes(scope)))
      throw this.denied("token lacks a required scope", { sub: principal.sub, requiredScopes: auth.scopes });
  }
  async checkPermission(principal, auth) {
    const permission = auth.permission;
    const options = { failOpen: auth.failOpen, highRisk: auth.highRisk };
    const permitted = principal.org ? await this.client.check({ action: permission, organisationId: principal.org, principal }, options) : auth.failOpen ?? false;
    if (!permitted)
      throw this.denied("permission denied", { sub: principal.sub, permission });
  }
  unauthenticated(error) {
    this.logger.warn("bearer token rejected", { reason: error.message });
    return AuthGuardErrorCode.IAM_001.create();
  }
  denied(message, metadata) {
    this.logger.warn(message, metadata);
    return AuthGuardErrorCode.IAM_002.create();
  }
}
AuthGuard = __legacyDecorateClassTS([
  Middleware({ type: "preHandler", weight: 100 }),
  __legacyMetadataTS("design:paramtypes", [
    typeof AuthClient === "undefined" ? Object : AuthClient,
    typeof ContextService === "undefined" ? Object : ContextService
  ])
], AuthGuard);
// src/module/auth.module.ts
import { Inject, Injectable, Module } from "@shadow-library/app";
import { Logger as Logger2 } from "@shadow-library/common";
import { ContextService as ContextService2, FastifyModule } from "@shadow-library/fastify";

// src/module/config.ts
import { Config } from "@shadow-library/common";
Config.load("auth.issuer");
Config.load("auth.audience");
Config.load("auth.client.id");
Config.load("auth.client.secret");
Config.load("auth.client.assertion-path");
function resolveAuthClientConfig(options = {}) {
  const issuer = options.issuer ?? Config.get("auth.issuer");
  const audience = options.audience ?? Config.get("auth.audience");
  let client = options.client;
  const clientId = Config.get("auth.client.id");
  if (!client && clientId) {
    client = { id: clientId, secret: Config.get("auth.client.secret") || undefined, assertionPath: Config.get("auth.client.assertion-path") || undefined };
  }
  return { ...options, issuer, audience, client };
}

// src/module/auth.module.ts
var AUTH_CONFIG = Symbol("shadow-library:auth-config");

class AuthInitializer {
  client;
  context;
  config;
  logger = Logger2.getLogger(NAMESPACE, AuthInitializer.name);
  constructor(client, context, config) {
    this.client = client;
    this.context = context;
    this.config = config;
  }
  async onModuleInit() {
    extendContextWithAuth(this.context);
    if (this.config.roles)
      await this.client.syncRoles(this.config.roles);
    if (this.config.client)
      await this.client.loadServiceAccess();
    this.logger.info("auth module initialised", { rolesDeclared: Boolean(this.config.roles), serviceAccessLoaded: Boolean(this.config.client) });
  }
}
AuthInitializer = __legacyDecorateClassTS([
  Injectable(),
  __legacyDecorateParamTS(2, Inject(AUTH_CONFIG)),
  __legacyMetadataTS("design:paramtypes", [
    typeof AuthClient === "undefined" ? Object : AuthClient,
    typeof ContextService2 === "undefined" ? Object : ContextService2,
    typeof AuthClientConfig === "undefined" ? Object : AuthClientConfig
  ])
], AuthInitializer);

class AuthModule {
  static forRoot(options = {}) {
    const config = resolveAuthClientConfig(options);
    const client = new AuthClient(config);
    return {
      module: AuthModule,
      imports: [FastifyModule],
      controllers: [AuthGuard],
      providers: [
        { token: AuthClient, useValue: client },
        { token: AUTH_CONFIG, useValue: config },
        { token: AuthInitializer, useClass: AuthInitializer }
      ],
      exports: [AuthClient]
    };
  }
}
AuthModule = __legacyDecorateClassTS([
  Module({})
], AuthModule);
// src/module/decorators.ts
import { Handler } from "@shadow-library/app";
var authRoute = (metadata) => Handler({ [AUTH_ROUTE_METADATA]: metadata });
var Authenticated = () => authRoute({ authenticated: true });
var RequireScope = (...scopes) => authRoute({ authenticated: true, scopes });
var RequirePermission = (permission, options = {}) => authRoute({ authenticated: true, permission, ...options });
// src/module/relying-party.module.ts
import { Module as Module2 } from "@shadow-library/app";
import { Config as Config2 } from "@shadow-library/common";
class RelyingPartyModule {
  static forRoot(options) {
    const relyingParty = new RelyingParty({ ...options, issuer: options.issuer ?? Config2.get("auth.issuer") });
    return {
      module: RelyingPartyModule,
      providers: [{ token: RelyingParty, useValue: relyingParty }],
      exports: [RelyingParty]
    };
  }
}
RelyingPartyModule = __legacyDecorateClassTS([
  Module2({})
], RelyingPartyModule);
export {
  resolveAuthClientConfig,
  extendContextWithAuth,
  RequireScope,
  RequirePermission,
  RelyingPartyModule,
  Authenticated,
  AuthModule,
  AuthGuardErrorCode,
  AuthGuard,
  AUTH_ROUTE_METADATA,
  AUTH_PRINCIPAL
};
