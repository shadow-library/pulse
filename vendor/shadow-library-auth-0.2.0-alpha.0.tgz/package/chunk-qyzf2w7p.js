// @bun
// src/errors.ts
import { ErrorCode } from "@shadow-library/common";

class AuthErrorCode extends ErrorCode {
  static CONFIG_INVALID = AuthErrorCode.internal("CONFIG_INVALID", "Auth client configuration is invalid: {reason}");
  static ALG_REJECTED = AuthErrorCode.unauthenticated("ALG_REJECTED", "Token algorithm is not allowed");
  static AUDIENCE_MISMATCH = AuthErrorCode.unauthenticated("AUDIENCE_MISMATCH", "Token is not addressed to this audience");
  static ISSUER_MISMATCH = AuthErrorCode.unauthenticated("ISSUER_MISMATCH", "Token issuer is not trusted");
  static KEY_UNKNOWN = AuthErrorCode.unauthenticated("KEY_UNKNOWN", "No published key matches the token");
  static NONCE_MISMATCH = AuthErrorCode.unauthenticated("NONCE_MISMATCH", "Token nonce does not match the expected nonce");
  static TOKEN_EXPIRED = AuthErrorCode.unauthenticated("TOKEN_EXPIRED", "Token has expired");
  static TOKEN_INVALID = AuthErrorCode.unauthenticated("TOKEN_INVALID", "Token is invalid: {reason}");
  static DISCOVERY_FAILED = AuthErrorCode.unavailable("DISCOVERY_FAILED", "OIDC discovery failed: {reason}");
  static EXCHANGE_FAILED = AuthErrorCode.unavailable("EXCHANGE_FAILED", "Authorization code exchange failed: {reason}");
  static INTROSPECTION_FAILED = AuthErrorCode.unavailable("INTROSPECTION_FAILED", "Token introspection failed: {reason}");
  static PDP_UNAVAILABLE = AuthErrorCode.unavailable("PDP_UNAVAILABLE", "Policy decision point is unavailable: {reason}");
  static ROLE_SYNC_FAILED = AuthErrorCode.unavailable("ROLE_SYNC_FAILED", "Role catalog sync failed: {reason}");
  static SERVICE_ACCESS_FAILED = AuthErrorCode.unavailable("SERVICE_ACCESS_FAILED", "Service access rules could not be loaded: {reason}");
  static SERVICE_UNKNOWN = AuthErrorCode.notFound("SERVICE_UNKNOWN", "Unknown service: {reason}");
  static TOKEN_REQUEST_FAILED = AuthErrorCode.unavailable("TOKEN_REQUEST_FAILED", "Token request failed: {reason}");
}
/*!
   * Configuration Errors
   */
/*!
   * Token Verification Errors
   */
/*!
   * OIDC Relying-Party Errors
   */
/*!
   * Machine-to-Machine Errors
   */

// src/lib/jwt.ts
var encoder = new TextEncoder;
function decodeSegment(segment, description) {
  try {
    return JSON.parse(Buffer.from(segment, "base64url").toString("utf8"));
  } catch {
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: `malformed jwt ${description}` });
  }
}
function decodeJwt(token) {
  const segments = token.split(".");
  const [head, body, signature] = segments;
  if (segments.length !== 3 || !head || !body || !signature)
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: "a jwt must have exactly three segments" });
  return {
    header: decodeSegment(head, "header"),
    payload: decodeSegment(body, "payload"),
    signingInput: encoder.encode(`${head}.${body}`),
    signature: new Uint8Array(Buffer.from(signature, "base64url"))
  };
}
function validateClaims(payload, expected) {
  const now = Math.floor(Date.now() / 1000);
  const skew = expected.clockSkewSeconds;
  if (payload.iss !== expected.issuer)
    throw AuthErrorCode.ISSUER_MISMATCH.create({ reason: `token issued by '${String(payload.iss)}'` });
  const audiences = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!audiences.includes(expected.audience))
    throw AuthErrorCode.AUDIENCE_MISMATCH.create({ reason: `token is not addressed to '${expected.audience}'` });
  if (typeof payload.exp !== "number")
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: "missing exp claim" });
  if (payload.exp <= now - skew)
    throw AuthErrorCode.TOKEN_EXPIRED.create({ reason: "token has expired" });
  if (typeof payload.nbf === "number" && payload.nbf > now + skew)
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: "token is not yet valid" });
  if (expected.nonce !== undefined && payload.nonce !== expected.nonce)
    throw AuthErrorCode.NONCE_MISMATCH.create({ reason: "token nonce does not match the expected nonce" });
}
async function verifyJwt(token, getKey, expected) {
  const { header, payload, signingInput, signature } = decodeJwt(token);
  if (header.alg !== "EdDSA")
    throw AuthErrorCode.ALG_REJECTED.create({ reason: `algorithm '${String(header.alg)}' is not allowed` });
  if (!header.kid)
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: "missing kid header" });
  const key = await getKey(header.kid);
  const isValid = await crypto.subtle.verify("Ed25519", key, signature, signingInput);
  if (!isValid)
    throw AuthErrorCode.TOKEN_INVALID.create({ reason: "signature verification failed" });
  validateClaims(payload, expected);
  return payload;
}

// src/constants.ts
var NAMESPACE = "@shadow-library/auth";

// src/lib/discovery.ts
import { Logger, throwError } from "@shadow-library/common";
class DiscoveryClient {
  issuer;
  fetchFn;
  logger = Logger.getLogger(NAMESPACE, DiscoveryClient.name);
  document = null;
  inflight = null;
  constructor(issuer, fetchFn) {
    this.issuer = issuer;
    this.fetchFn = fetchFn;
  }
  async get() {
    if (this.document)
      return this.document;
    this.inflight ??= this.load().finally(() => this.inflight = null);
    return this.inflight;
  }
  async load() {
    this.logger.debug("fetching oidc discovery document", { issuer: this.issuer });
    const response = await this.fetchFn(`${this.issuer}/.well-known/openid-configuration`).catch((error) => throwError(this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: `discovery fetch failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: `discovery endpoint returned http ${response.status}` }));
    const document = await response.json();
    if (document.issuer !== this.issuer)
      throw this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: "discovery issuer does not match the configured issuer" }));
    if (!document.jwks_uri || !document.token_endpoint)
      throw this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: "discovery document is missing required endpoints" }));
    this.document = document;
    this.logger.info("oidc discovery document loaded", { issuer: this.issuer });
    return document;
  }
  logged(error) {
    this.logger.error(error.message, { issuer: this.issuer });
    return error;
  }
}

// src/lib/jwks.ts
import { Logger as Logger2, throwError as throwError2 } from "@shadow-library/common";
var NEGATIVE_CACHE_MS = 1e4;

class RemoteJwks {
  options;
  logger = Logger2.getLogger(NAMESPACE, RemoteJwks.name);
  keys = new Map;
  fetchedAt = 0;
  lastMissAt = 0;
  inflight = null;
  constructor(options) {
    this.options = options;
  }
  async getKey(kid) {
    const isStale = Date.now() - this.fetchedAt >= this.options.ttlSeconds * 1000;
    if (isStale) {
      await this.refresh().catch((error) => {
        if (this.keys.size === 0)
          throw error;
        this.logger.warn("jwks refresh failed; serving cached keys", { reason: error.message });
      });
    }
    let key = this.keys.get(kid);
    if (!key && Date.now() - this.lastMissAt > NEGATIVE_CACHE_MS) {
      this.logger.debug("unknown kid, refetching jwks", { kid });
      await this.refresh();
      key = this.keys.get(kid);
      if (!key)
        this.lastMissAt = Date.now();
    }
    if (!key) {
      this.logger.warn("no published key matches the token kid", { kid });
      throw AuthErrorCode.KEY_UNKNOWN.create({ reason: `no published key matches kid '${kid}'` });
    }
    return key;
  }
  refresh() {
    this.inflight ??= this.load().finally(() => this.inflight = null);
    return this.inflight;
  }
  async load() {
    const document = await this.options.discovery.get();
    this.logger.debug("fetching jwks", { url: document.jwks_uri });
    const response = await this.options.fetchFn(document.jwks_uri).catch((error) => throwError2(this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: `jwks fetch failed: ${error.message}` }))));
    if (!response.ok)
      throw this.logged(AuthErrorCode.DISCOVERY_FAILED.create({ reason: `jwks endpoint returned http ${response.status}` }));
    const body = await response.json();
    const keys = new Map;
    for (const jwk of body.keys ?? []) {
      if (jwk.kty !== "OKP" || jwk.crv !== "Ed25519" || !jwk.kid)
        continue;
      keys.set(jwk.kid, await crypto.subtle.importKey("jwk", jwk, "Ed25519", false, ["verify"]));
    }
    this.keys = keys;
    this.fetchedAt = Date.now();
    this.logger.info("jwks refreshed", { keyCount: keys.size });
  }
  logged(error) {
    this.logger.error(error.message);
    return error;
  }
}

export { AuthErrorCode, NAMESPACE, DiscoveryClient, RemoteJwks, decodeJwt, validateClaims, verifyJwt };
