/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
import { JwtPayload, PrincipalKind, ServiceAccessRule } from '../interfaces';
/**
 * Defining types
 */
export interface TestIdPOptions {
    /** Overrides the issuer advertised in discovery; defaults to the bound server url */
    issuer?: string;
    /** When set, the token endpoint enforces these client credentials */
    clientId?: string;
    clientSecret?: string;
    accessTokenTtlSeconds?: number;
}
export interface TestTokenInput {
    sub: string;
    kind?: PrincipalKind;
    audience?: string | string[];
    scopes?: string[];
    org?: string;
    sid?: string;
    clientId?: string;
    /** May be negative to mint already-expired tokens */
    ttlSeconds?: number;
    claims?: JwtPayload;
}
export interface TestPrincipalRef {
    kind: PrincipalKind;
    sub: string;
}
export interface CapturedCatalog {
    manifest: {
        permissions: unknown[];
        roles: unknown[];
    };
    authorization: string | null;
}
export interface CapturedTokenRequest {
    body: Record<string, unknown>;
    authorization: string | null;
}
export interface TestIdP {
    issuer: string;
    /** Mints a signed token with sensible claim defaults */
    issueToken(input: TestTokenInput): Promise<string>;
    /** Signs exactly the given claims — no defaults are applied */
    signToken(claims: JwtPayload): Promise<string>;
    /** Registers a single-use authorization code redeemable at the token endpoint */
    createAuthorizationCode(input: TestTokenInput & {
        nonce?: string;
    }): string;
    grantPermission(principal: TestPrincipalRef, organisationId: string, action: string): void;
    revokePermission(principal: TestPrincipalRef, organisationId: string, action: string): void;
    bumpAuthzVersion(): void;
    /** Replaces the signing key; previous public keys stay published, mirroring real rotation */
    rotateKeys(): Promise<void>;
    /** Makes an endpoint answer http 503 until re-enabled */
    setEndpointFailure(pathname: string, fail: boolean): void;
    getRequestCount(pathname: string): number;
    /** Returns the most recent role-catalog sync the mock received, if any */
    getLastCatalog(): CapturedCatalog | undefined;
    /** Configures the rules the `/api/v1/authz/service-access` endpoint returns */
    setServiceAccess(rules: ServiceAccessRule[]): void;
    /** Returns the most recent token-endpoint request the mock received, if any */
    getLastTokenRequest(): CapturedTokenRequest | undefined;
    stop(): void;
}
/**
 * Spins an in-process mock identity provider: an ephemeral Ed25519 key, discovery + JWKS + token +
 * PDP endpoints on a random port. Consuming services integration-test their guards against it
 * without a running identity service.
 */
export declare function createTestIdP(options?: TestIdPOptions): Promise<TestIdP>;
