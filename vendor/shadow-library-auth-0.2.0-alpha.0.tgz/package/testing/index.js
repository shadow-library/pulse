// @bun
import"../chunk-561v8w9j.js";

// src/testing/signer.ts
var encoder = new TextEncoder;
var encodeSegment = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
async function createTestSigner() {
  const pair = await crypto.subtle.generateKey("Ed25519", true, ["sign", "verify"]);
  const kid = crypto.randomUUID();
  const jwk = await crypto.subtle.exportKey("jwk", pair.publicKey);
  const publicJwk = { ...jwk, kid, alg: "EdDSA", use: "sig" };
  const sign = async (claims) => {
    const signingInput = `${encodeSegment({ alg: "EdDSA", typ: "JWT", kid })}.${encodeSegment(claims)}`;
    const signature = await crypto.subtle.sign("Ed25519", pair.privateKey, encoder.encode(signingInput));
    return `${signingInput}.${Buffer.from(signature).toString("base64url")}`;
  };
  return { kid, publicJwk, sign };
}
// src/testing/test-idp.ts
var DEFAULT_ACCESS_TOKEN_TTL_SECONDS = 600;
var DEFAULT_AUDIENCE = "shadow-identity";
var json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
async function createTestIdP(options = {}) {
  let signer = await createTestSigner();
  const retiredJwks = [];
  const requestCounts = new Map;
  const failingEndpoints = new Set;
  const authorizationCodes = new Map;
  const refreshTokens = new Map;
  const grants = new Set;
  let authzVersion = 1;
  let issuer = "";
  let lastCatalog;
  let lastTokenRequest;
  let serviceAccessRules = [];
  const ttl = options.accessTokenTtlSeconds ?? DEFAULT_ACCESS_TOKEN_TTL_SECONDS;
  const buildClaims = (input) => {
    const now = Math.floor(Date.now() / 1000);
    const kind = input.kind ?? "user";
    const claims = {
      iss: issuer,
      sub: input.sub,
      aud: input.audience ?? DEFAULT_AUDIENCE,
      iat: now,
      exp: now + (input.ttlSeconds ?? ttl),
      jti: crypto.randomUUID(),
      token_type: kind,
      scope: (input.scopes ?? []).join(" ")
    };
    if (input.clientId)
      claims.client_id = input.clientId;
    if (input.org)
      claims.org = input.org;
    if (input.sid)
      claims.sid = input.sid;
    return { ...claims, ...input.claims };
  };
  const issueToken = (input) => signer.sign(buildClaims(input));
  const isClientAuthorized = (request, body) => {
    if (!options.clientId)
      return true;
    const header = request.headers.get("authorization");
    if (header?.startsWith("Basic ")) {
      const decoded = Buffer.from(header.slice(6), "base64").toString();
      return decoded === `${options.clientId}:${options.clientSecret ?? ""}`;
    }
    if (typeof body.client_assertion === "string" && body.client_assertion.length > 0)
      return body.client_id === options.clientId;
    return body.client_id === options.clientId && (options.clientSecret === undefined || body.client_secret === options.clientSecret);
  };
  const readTokenBody = async (request) => {
    const contentType = request.headers.get("content-type") ?? "";
    if (contentType.includes("application/x-www-form-urlencoded"))
      return Object.fromEntries(new URLSearchParams(await request.text()));
    return await request.json().catch(() => ({}));
  };
  const handleToken = async (request) => {
    const body = await readTokenBody(request);
    lastTokenRequest = { body, authorization: request.headers.get("authorization") };
    if (!isClientAuthorized(request, body))
      return json({ error: "invalid_client" }, 401);
    if (body.grant_type === "client_credentials") {
      const clientId = options.clientId ?? (typeof body.client_id === "string" ? body.client_id : "test-client");
      const scopes = typeof body.scope === "string" ? body.scope.split(" ").filter(Boolean) : [];
      const audience = typeof body.resource === "string" ? body.resource : undefined;
      const accessToken = await issueToken({ sub: clientId, kind: "service", clientId, scopes, audience });
      return json({ access_token: accessToken, token_type: "Bearer", expires_in: ttl, scope: scopes.join(" ") });
    }
    if (body.grant_type === "authorization_code") {
      const code = typeof body.code === "string" ? body.code : "";
      const stored = authorizationCodes.get(code);
      if (!stored)
        return json({ error: "invalid_grant" }, 400);
      authorizationCodes.delete(code);
      const clientId = options.clientId ?? stored.clientId ?? "test-client";
      const accessToken = await issueToken({ ...stored, clientId });
      const now = Math.floor(Date.now() / 1000);
      const idClaims = { iss: issuer, sub: stored.sub, aud: clientId, iat: now, exp: now + ttl, auth_time: now, ...stored.claims };
      if (stored.nonce)
        idClaims.nonce = stored.nonce;
      const idToken = await signer.sign(idClaims);
      const refreshToken = crypto.randomUUID();
      refreshTokens.set(refreshToken, stored);
      return json({ access_token: accessToken, id_token: idToken, token_type: "Bearer", expires_in: ttl, scope: (stored.scopes ?? []).join(" "), refresh_token: refreshToken });
    }
    if (body.grant_type === "refresh_token") {
      const presented = typeof body.refresh_token === "string" ? body.refresh_token : "";
      const stored = refreshTokens.get(presented);
      if (!stored)
        return json({ error: "invalid_grant" }, 400);
      refreshTokens.delete(presented);
      const accessToken = await issueToken(stored);
      const rotated = crypto.randomUUID();
      refreshTokens.set(rotated, stored);
      return json({ access_token: accessToken, token_type: "Bearer", expires_in: ttl, scope: (stored.scopes ?? []).join(" "), refresh_token: rotated });
    }
    return json({ error: "unsupported_grant_type" }, 400);
  };
  const handleAuthzCheck = async (request) => {
    const body = await request.json().catch(() => ({}));
    const kind = body.principalType === "SERVICE_ACCOUNT" ? "service" : "user";
    const key = `${kind}:${String(body.principalId)}:${String(body.organisationId)}:${String(body.action)}`;
    const decision = grants.has(key) ? "PERMIT" : "DENY";
    return json({ decision, reasons: decision === "DENY" ? ["no matching grant"] : [], authzVersion });
  };
  const handleCatalog = async (request) => {
    const manifest = await request.json().catch(() => ({ permissions: [], roles: [] }));
    const permissions = manifest.permissions ?? [];
    const roles = manifest.roles ?? [];
    lastCatalog = { manifest: { permissions, roles }, authorization: request.headers.get("authorization") };
    return json({ permissionsUpserted: permissions.length, permissionsDeleted: 0, rolesUpserted: roles.length, rolesDeleted: 0, principalsInvalidated: 0 });
  };
  const handle = async (request) => {
    const url = new URL(request.url);
    requestCounts.set(url.pathname, (requestCounts.get(url.pathname) ?? 0) + 1);
    if (failingEndpoints.has(url.pathname))
      return new Response("injected failure", { status: 503 });
    switch (url.pathname) {
      case "/.well-known/openid-configuration":
        return json({
          issuer,
          jwks_uri: `${issuer}/.well-known/jwks.json`,
          token_endpoint: `${issuer}/oauth2/token`,
          authorization_endpoint: `${issuer}/oauth2/authorize`,
          userinfo_endpoint: `${issuer}/oauth2/userinfo`
        });
      case "/.well-known/jwks.json":
        return json({ keys: [signer.publicJwk, ...retiredJwks] });
      case "/oauth2/token":
        return handleToken(request);
      case "/api/v1/authz/check":
        return handleAuthzCheck(request);
      case "/api/v1/authz/catalog":
        return handleCatalog(request);
      case "/api/v1/authz/service-access":
        return json({ rules: serviceAccessRules });
      default:
        return new Response("not found", { status: 404 });
    }
  };
  const server = Bun.serve({ port: 0, fetch: handle });
  issuer = options.issuer ?? `http://127.0.0.1:${server.port}`;
  const grantKey = (principal, organisationId, action) => `${principal.kind}:${principal.sub}:${organisationId}:${action}`;
  return {
    issuer,
    issueToken,
    signToken: (claims) => signer.sign(claims),
    createAuthorizationCode: (input) => {
      const code = crypto.randomUUID();
      authorizationCodes.set(code, input);
      return code;
    },
    grantPermission: (principal, organisationId, action) => void grants.add(grantKey(principal, organisationId, action)),
    revokePermission: (principal, organisationId, action) => void grants.delete(grantKey(principal, organisationId, action)),
    bumpAuthzVersion: () => void (authzVersion += 1),
    rotateKeys: async () => {
      retiredJwks.push(signer.publicJwk);
      signer = await createTestSigner();
    },
    setEndpointFailure: (pathname, fail) => void (fail ? failingEndpoints.add(pathname) : failingEndpoints.delete(pathname)),
    getRequestCount: (pathname) => requestCounts.get(pathname) ?? 0,
    getLastCatalog: () => lastCatalog,
    setServiceAccess: (rules) => void (serviceAccessRules = rules),
    getLastTokenRequest: () => lastTokenRequest,
    stop: () => void server.stop(true)
  };
}
export {
  createTestSigner,
  createTestIdP
};
