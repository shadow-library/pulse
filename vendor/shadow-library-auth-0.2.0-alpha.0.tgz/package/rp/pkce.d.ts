/**
 * Importing npm packages
 */
/**
 * Importing user defined packages
 */
/**
 * Defining types
 */
export interface PkcePair {
    verifier: string;
    challenge: string;
}
export declare function randomUrlSafeString(bytes?: number): string;
/** Generates an RFC 7636 S256 verifier/challenge pair */
export declare function createPkcePair(): Promise<PkcePair>;
